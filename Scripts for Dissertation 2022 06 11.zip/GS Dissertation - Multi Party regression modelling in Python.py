# -*- coding: utf-8 -*-
"""
Created on Wed May 18 15:23:35 2022

@author: 35385
"""

## Load the packages

import os 

import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn import preprocessing

from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix 

from sklearn.linear_model import LinearRegression as Reg
from sklearn.svm import SVC as SVC
from sklearn.svm import SVR as SVR
from sklearn.ensemble import RandomForestRegressor as RFR
from sklearn.ensemble import RandomForestClassifier as RFC
from sklearn.tree import DecisionTreeClassifier as DTC
from sklearn.tree import DecisionTreeRegressor as DTR

from sklearn.neighbors import KNeighborsClassifier as kNN
from sklearn.naive_bayes import  GaussianNB as GNB, CategoricalNB as CNB
from sklearn.linear_model import Lasso
from sklearn.neural_network import MLPRegressor

from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import SelectKBest, chi2, mutual_info_classif
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score

DF = pd.read_csv('https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/MP%20Dataset%201%20Train.csv', encoding = 'cp1252') # load the CSV

DF.pop('Constituency')

DF.pop('Election_Period')

DF['Multi-party'].unique()

DF_FF = DF[ DF['Multi-party'] == 'FF']

DF_FG = DF[ DF['Multi-party'] == 'FG']

DF_SF = DF[ DF['Multi-party'] == 'SF']

DF_Left = DF[ DF['Multi-party'] == 'GP-LAB-SD']

DF_Other = DF[ DF['Multi-party'] == 'All Others']

y_FF = DF_FF.pop('FP_Share').values

y_FG = DF_FG.pop('FP_Share').values

y_SF = DF_SF.pop('FP_Share').values

y_Left = DF_Left.pop('FP_Share').values

y_Other = DF_Other.pop('FP_Share').values

X_FF = DF_FF

X_FG = DF_FG

X_SF = DF_SF

X_Left = DF_Left

X_Other = DF_Other

# load test data

DF_test_red = pd.read_csv('https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/MP%20Dataset%201%20Test.csv', encoding = 'cp1252') # load the CSV

DF_test_red.pop('Constituency')

DF_test_red.pop('Election_Period')

DF_test_red_FF = DF_test_red [ DF_test_red ['Multi-party'] == 'FF']

DF_test_red_FG = DF_test_red [ DF_test_red ['Multi-party'] == 'FG']

DF_test_red_SF = DF_test_red [ DF_test_red['Multi-party'] == 'SF']

DF_test_red_Left = DF_test_red [ DF_test_red ['Multi-party'] == 'GP-LAB-SD']

DF_test_red_Other = DF_test_red [ DF_test_red ['Multi-party'] == 'All Others']


y_test_red_FF = DF_test_red_FF.pop('FP_Share').values

y_test_red_FG = DF_test_red_FG.pop('FP_Share').values

y_test_red_SF = DF_test_red_SF.pop('FP_Share').values

y_test_red_Left = DF_test_red_Left.pop('FP_Share').values

y_test_red_Other = DF_test_red_Other.pop('FP_Share').values

X_FF_test = DF_test_red_FF

X_FG_test = DF_test_red_FG

X_SF_test = DF_test_red_SF

X_Left_test = DF_test_red_Left

X_Other_test = DF_test_red_Other

# create multiple DFs - one per party / group

X_FF_test.pop('Multi-party')
X_FG_test.pop('Multi-party')
X_SF_test.pop('Multi-party')
X_Left_test.pop('Multi-party')
X_Other_test.pop('Multi-party')
X_FF.pop('Multi-party')
X_FG.pop('Multi-party')
X_SF.pop('Multi-party')
X_Left.pop('Multi-party')
X_Other.pop('Multi-party')

feature_names = X_Other.columns


min_max_scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))

X_Other_test = pd.DataFrame(min_max_scaler.fit_transform(X_Other_test))
X_Left_test = pd.DataFrame(min_max_scaler.fit_transform(X_Left_test))
X_SF_test = pd.DataFrame(min_max_scaler.fit_transform(X_SF_test))
X_FG_test = pd.DataFrame(min_max_scaler.fit_transform(X_FG_test))
X_FF_test  = pd.DataFrame(min_max_scaler.fit_transform(X_FF_test ))

X_Other = pd.DataFrame(min_max_scaler.fit_transform(X_Other))
X_Left = pd.DataFrame(min_max_scaler.fit_transform(X_Left))
X_SF = pd.DataFrame(min_max_scaler.fit_transform(X_SF))
X_FG = pd.DataFrame(min_max_scaler.fit_transform(X_FG))
X_FF  = pd.DataFrame(min_max_scaler.fit_transform(X_FF))


## create a function to run each DF through

def train_model(X, y, X_Test, y_Test):
    Lasso_ = Lasso()
    param_grid_Lasso = {'alpha': [1, 0.2, 0.1, 0.05, 0.01,0.00001], 'max_iter': [10000, 100000, 100000000, 1000000000]   ,
             'selection':['cyclic', 'random'],
              'fit_intercept':[False]}

    Lasso_gs = GridSearchCV(Lasso_,param_grid_Lasso, 
                      verbose = 5, n_jobs = -1 )
    Lasso_gs = Lasso_gs.fit(X, y)

    print(Lasso_gs.best_params_)


    print(Lasso_gs.score(X, y))

    Lasso_predict = pd.DataFrame(Lasso_gs.predict(X))
    Lasso_train_R_Sq = r2_score(Lasso_predict , y)
    print('LASSO R Squared score:')
    print(Lasso_train_R_Sq)

    print('LASSO Best Fit Params:')
    print(Lasso_gs.best_params_)
    
    SVR_ = SVR()
    
    param_grid_svr = {'kernel':['poly', 'linear', 'rbf'],    
                  'C': [0.1, 1, 10, 100, 1000], 
                 'shrinking':[1,0],
                 'gamma': ['scale','auto'],
                 'epsilon':[1, 0.1, 0.01, 0.001, 0.0001]}
    
    
    SVR_gs = GridSearchCV(SVR(),param_grid_svr,cv=10,  
                          verbose = 5, n_jobs = -1)
    
    SVR_gs.fit(X, y)
    
    SVR_gs.score(X, y)
    
  
    SVR_predict = pd.DataFrame(SVR_gs.predict(X))
    SVR_train_R_Sq = r2_score(SVR_predict , y)
    print('SVR R Squared score:')
    print(SVR_train_R_Sq)

    print('SVR Best Fit Params:')
    print(SVR_gs.best_params_)
    
    RF = RFR()
    
    
    param_grid_RF = {'min_samples_leaf': [1,3,5],    
                  'max_features': ['auto', 'sqrt', 'log2']}
    
    RF_gs = GridSearchCV(RF,param_grid_RF ,cv=10,  
                          verbose = 5, n_jobs = -1)
    
    RF_gs.fit(X, y)
    
    RF_gs.score(X, y)
    
    RF_gs_predict = pd.DataFrame(RF_gs.predict(X))
    
    
    RF_train_R_Sq = r2_score(RF_gs_predict , y)
    print('RFR R Squared score:')
    print(RF_train_R_Sq )

    print('RFR Best Fit Params:')
    print(RF_gs.best_params_)
    
    mlp = MLPRegressor()
        
    param_grid_mlp = {'hidden_layer_sizes': [5,10,20],    
                  'activation': ['identity', 'logistic', 'tanh', 'relu'], 
                 'solver':['lbfgs', 'sgd', 'adam'],
                 'alpha': [0.01, 0.001,0.0001,0.00001],
                 'learning_rate':['constant', 'invscaling', 'adaptive'], 'max_iter':[1000],
                 'random_state':[42]}
    
    mlp_gs = GridSearchCV(mlp,param_grid_mlp,cv=10,  
                          verbose = 5, n_jobs = -1)
    
    mlp_gs.fit(X, y)
    
    mlp_gs.score(X, y)
    
    MLP_predict = pd.DataFrame(mlp_gs.predict(X))
    
    mlp_train_R_Sq = r2_score(MLP_predict , y)
    print('MLP R Squared score:')
    print(mlp_train_R_Sq )

    print('MLP Best Fit Params:')
    print(mlp_gs.best_params_)
    
    
    param_grid_svr_lin = {'kernel':['linear'],    
                  'C': [0.1, 1, 10, 100, 1000], 
                 'shrinking':[1,0],
                 'gamma': ['scale','auto'],
                 'epsilon':[1, 0.1, 0.01, 0.001, 0.0001]}

    SVR_LIN_gs = GridSearchCV(SVR(),param_grid_svr_lin,cv=10,  
                          verbose = 5, n_jobs = -1)
    
    SVR_LIN_gs.fit(X, y)
    
    SVR_LIN_gs.score(X, y)
    
  
    SVR_LIN_predict = pd.DataFrame(SVR_LIN_gs.predict(X))
    SVR_LIN_train_R_Sq = r2_score(SVR_LIN_predict , y)
    print('SVR_LIN R Squared score:')
    print(SVR_LIN_train_R_Sq)

    print('SVR_LIN Best Fit Params:')
    print(SVR_LIN_gs.best_params_)
    
    
    RF_gs_predict_test = pd.DataFrame(RF_gs.predict(X_Test))
    
    RF_R_Sq = r2_score(RF_gs_predict_test, y_Test)
    print('RFR TEST R Squared score:')

    print(RF_R_Sq )
    
    
    SVR_LIN_gs_predict_test = pd.DataFrame(SVR_LIN_gs.predict(X_Test))
    
    SVR_LIN_gs_R_Sq = r2_score(SVR_LIN_gs_predict_test, y_Test)
    print('SVR Linear TEST R Squared score:')
    print(SVR_LIN_gs_R_Sq )
            
    
    SVR_gs_predict_test = pd.DataFrame(SVR_gs.predict(X_Test))
    
    SVR_R_Sq = r2_score(SVR_gs_predict_test, y_Test)
    print('SVR TEST R Squared score:')
    print(SVR_R_Sq )
    
    mlp_gs_predict_test = pd.DataFrame(mlp_gs.predict(X_Test))
    
    mlp_R_Sq = r2_score(mlp_gs_predict_test, y_Test)
    print('MLP TEST R Squared score:')
    print(mlp_R_Sq )
    
    Lasso_gs_predict_test = pd.DataFrame(Lasso_gs.predict(X_Test))
    
    LASSO_R_Sq = r2_score(Lasso_gs_predict_test, y_Test)
    print(' LASSO TEST R Squared score:')
    print(LASSO_R_Sq )
    
    # MSE
    
    LASSO_mse = mean_squared_error(Lasso_predict, y)
    print('LASSO MSE:')
    print(LASSO_mse)
        
    MLP_test_mse = mean_squared_error(MLP_predict, y)
    print('MLP MSE:')
    print(MLP_test_mse)
    
         
    RF_mse = mean_squared_error(RF_gs_predict, y)
    print('RF MSE:')
    print(RF_mse)
       
         
    SVR_mse = mean_squared_error(SVR_predict, y)
    print('SVR MSE:')
    print(SVR_mse)
    
    LASSO_test_mse = mean_squared_error(Lasso_gs_predict_test, y_Test)
    print(' LASSO TEST MSE:')
    print(LASSO_test_mse)
        
    MLP_test_mse = mean_squared_error(mlp_gs_predict_test, y_Test)
    print(' MLP TEST MSE:')
    print(MLP_test_mse)
    
         
    RF_test_mse = mean_squared_error(RF_gs_predict_test, y_Test)
    print('RF TEST MSE:')
    print(MLP_test_mse)
       
         
    SVR_test_mse = mean_squared_error(SVR_gs_predict_test, y_Test)
    print('SVR TEST MSE:')
    print(SVR_test_mse)
           
    

# run the trained models on test data to see performance in t+1


train_model(X_FF, y_FF, X_FF_test  , y_test_red_FF)
train_model(X_FG, y_FG, X_FG_test  , y_test_red_FG)
train_model(X_SF, y_SF, X_SF_test  , y_test_red_SF)
train_model(X_Left, y_Left, X_Left_test  , y_test_red_Left)
train_model(X_Other, y_Other, X_Other_test  , y_test_red_Other)

# extract insights from the model runs

# LASSO

Lasso_ = Lasso()

param_grid_Lasso = {'alpha': [1, 0.2, 0.1, 0.05, 0.01,0.00001], 'max_iter': [10000, 100000, 100000000, 1000000000]   ,
             'selection':['cyclic', 'random'],
              'fit_intercept':[False]}

Lasso_gs = GridSearchCV(Lasso_,param_grid_Lasso, 
                      verbose = 5, n_jobs = -1 )

Lasso_gs = Lasso_gs.fit(X_Left, y_Left)

# get feature importance for LASSO

array = Lasso_gs.best_estimator_.coef_
feat_imp = zip(*sorted(zip(array,feature_names)))
print(set(feat_imp))




# RFR 
forest = RFR(min_samples_leaf = 1, max_features = 'auto', random_state = 42)
#    max_features = 'sqrt'
forest.fit(X_Other, y_Other)
#get importance values

importances = forest.feature_importances_

from matplotlib import pyplot as pylt

feat_imp = []

def f_importances(coef, names):
    imp = coef
    feat_imp = zip(*sorted(zip(imp,names)))
    print(set(feat_imp))
    
print("RFR FEATURE IMPORTANCE")   
f_importances(importances, feature_names)

## svr linear

SVR_LIN_gs = SVR(C=0.1, shrinking = 0, gamma = 'scale', epsilon = 0.01, kernel = 'linear')

SVR_LIN_gs.fit(X_FF, y_FF)

array =  []

array =  SVR_LIN_gs.coef_

feat_imp = zip(*sorted(zip(array,feature_names)))
print(set(feat_imp))

feat_imp = []

def f_importances(coef, names):
    imp = coef
    feat_imp = zip(*sorted(zip(imp,names)))
    print("LINEAR SVR FEATURE IMPORTANCE")   
    print(set(feat_imp))

f_importances(SVR_LIN_gs.coef_, feature_names)

# lasso

Lasso_ = Lasso()
param_grid_Lasso = {'alpha': [1, 0.2, 0.1, 0.05, 0.01,0.00001], 'max_iter': [10000, 100000, 100000000, 1000000000]   ,
         'selection':['cyclic', 'random'],
          'fit_intercept':[False]}

Lasso_gs = GridSearchCV(Lasso_,param_grid_Lasso, 
                  verbose = 5, n_jobs = -1 )
Lasso_gs = Lasso_gs.fit(X_FF, y_FF)

Lasso_gs_feature_weights = Lasso_gs.best_estimator_.feature_importance()

Lasso_gs_feature_weights =zip(feature_names, Lasso_gs_feature_weights)

print(tuple(Lasso_gs_feature_weights))


# svr solo

SVR_ = SVR()

param_grid_svr = {'kernel':['linear'],    
              'C': [0.1, 1, 10, 100, 1000], 
             'shrinking':[1,0],
             'gamma': ['scale','auto'],
             'epsilon':[1, 0.1, 0.01, 0.001, 0.0001]}


SVR_gs = GridSearchCV(SVR(),param_grid_svr,cv=10,  
                      verbose = 5, n_jobs = -1)
SVR_gs.fit(X_Left, y_Left)

SVR_gs.score(X_Left, y_Left)

SVR_gs_feature_weights = SVR_gs.best_estimator_.coef_
SVR_gs_feature_weights =zip(feature_names, SVR_gs_feature_weights)
print(tuple(SVR_gs_feature_weights))

  
SVR_predict = pd.DataFrame(SVR_gs.predict(X_Left))
SVR_train_R_Sq = r2_score(SVR_predict , y_Left)
print('SVR R Squared score:')
print(SVR_train_R_Sq)


SVR_predict_test = pd.DataFrame(SVR_gs.predict(X_Left_test))
SVR_train_R_Sq = r2_score(SVR_predict_test , y_test_red_Left)
print('SVR TEST R Squared score:')
print(SVR_train_R_Sq)

SVR_mse = mean_squared_error(SVR_predict, y_Left)
print('SVR MSE:')
print(SVR_mse)

LASSO_test_mse = mean_squared_error(SVR_predict_test, y_test_red_Left)
print(' LASSO TEST MSE:')
print(LASSO_test_mse)


