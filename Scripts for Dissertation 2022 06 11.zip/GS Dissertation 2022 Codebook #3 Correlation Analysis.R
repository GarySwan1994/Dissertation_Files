### Dissertation Correlation analysis

# Check the 2016 data

df <- read.csv("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/2party_recent.csv")

needed_packages <- c("psych",  "REdaS", "Hmisc", "corrplot", "ggcorrplot", "factoextra",  "nFactors")                      
# Extract not installed packages
not_installed <- needed_packages[!(needed_packages %in% installed.packages()[ , "Package"])]  
if(length(not_installed)) install.packages(not_installed, repos = "http://cran.us.r-project.org") 

library(Hmisc)
library(corrplot)
library(ggcorrplot)

df_inputs = df[,c(-9)]
df_inputs = df_inputs[,c(-1)]


Input_Matrix<-cor(df_inputs)

round(Input_Matrix, 2)

Hmisc::rcorr(as.matrix(df_inputs))

p.mat <- ggcorrplot::cor_pmat(df_inputs)
ggcorrplot::ggcorrplot(Input_Matrix, title = "Correlation matrix for RAQ data")
#Showing Xs for non-significant correlations
ggcorrplot::ggcorrplot(Input_Matrix, title = "Correlation matrix for RAQ data", p.mat = p.mat, sig.level = .05)
#Showing lower diagonal
ggcorrplot::ggcorrplot(Input_Matrix, title = "Correlation matrix for Irish Electoral Prediction Inputs", p.mat = p.mat, sig.level = .05, type="lower")

write.csv(Input_Matrix,"correlation_diss_1.csv")