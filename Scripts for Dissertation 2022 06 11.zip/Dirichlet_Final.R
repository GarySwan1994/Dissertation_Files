## Script for Dirichlet regression 

## Gary Swan, May 2022


library(tidyverse)
library(brms)
library(rgdal)
library(knitr)
library(kableExtra)
library(StanHeaders)
library(rstan)
library(DirichletReg)

# load data

DF <- read.csv("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/Dirichlet%202020%20elec%20data%202022%2005%2024.csv")

DF$Y <- DR_data(DF[c(3,4,5,6,7)])
DF$Y

# baseline


# do model 1 on common


mod1 <- DirichReg(Y ~ pct_share_party_prior_election_All_Others + pct_share_party_prior_election_FF + pct_share_party_prior_election_FG + pct_share_party_prior_election_GP_LAB_SD + pct_share_party_prior_election_SF, data = DF)

mod1

summary(mod1)

# model 1 predictions

predict(mod1)

# drop1

drop1(mod1)

# do an R squared statsitic

predictions_mod1 <- predict(mod1)

observed = DF$Y

rsq <- function (x, y) cor(x, y) ^ 2

rsq(observed, predictions_mod1)

MSE_mod1 = mean((observed - predictions_mod1)^2) 

# predict on test attempt

DFt <- read.csv("Dirichlet 2020 elec data 2022 05 24.csv")

DFt$Y <- DR_data(DFt[c(3,4,5,6,7)])

observed_test <- DFt$Y

predictions_mod1_test <- predict(mod1, DFt)

rsq(observed_test, predictions_mod1_test)

MSE_mod1_test = mean((observed_test - predictions_mod1_test)^2) 

# do model 1c using good features from prior models on common


mod1c <- DirichReg(Y ~ incumbent_pct_FF + incumbent_pct_FG + Catholic_pct + UK_birth_pct + Two_person_household_ppl_pct, data = DF)

mod1c

summary(mod1c)

# model 1 predictions

predict(mod1c)

# drop1

drop1(mod1c)

# do an R squared statsitic

predictions_mod1c <- predict(mod1c)

observed = DF$Y

rsq <- function (x, y) cor(x, y) ^ 2

rsq(observed, predictions_mod1c)

MSE_mod1c = mean((observed - predictions_mod1c)^2) 


# predict on test attempt


predictions_mod1c_test <- predict(mod1c, DFt)

rsq(observed_test, predictions_mod1c_test)

MSE_mod1c_test = mean((observed_test - predictions_mod1c_test)^2) 

# alt mod


mod1a <- DirichReg(Y ~ incumbent_pct_All_Others + incumbent_pct_FF + incumbent_pct_FG + incumbent_pct_GP_LAB_SD + incumbent_pct_SF + candidates_per_seat_All_Others + candidates_per_seat_FF + candidates_per_seat_FG + candidates_per_seat_GP_LAB_SD + candidates_per_seat_SF + female_pct_All_Others + female_pct_FF + female_pct_FG + female_pct_GP_LAB_SD + female_pct_SF + Catholic_pct + Irish_over3_pct + Irish_Daily_And_In_Educ_pct + Two_person_household_ppl_pct + UK_birth_pct + Wh_irish_trv + pct_share_party_prior_election_All_Others + pct_share_party_prior_election_FF + pct_share_party_prior_election_FG + pct_share_party_prior_election_GP_LAB_SD + pct_share_party_prior_election_SF, data = DF, model = "alternative")

mod1a

summary(mod1a)

predict(mod1a)

# do drop one to discover which features to drop


drop1(mod1a) # shows which terms can be dropped from a statistical significant POV


# do an R squared statsitic

predictions_mod1a <- predict(mod1a)

observed = DF$Y

rsq <- function (x, y) cor(x, y) ^ 2

rsq(observed, predictions_mod1a)

MSE_mod1a = mean((observed - predictions_mod1a)^2) 

# R squared on test

predictions_mod1a_test <- predict(mod1a, DFt)

rsq(observed_test, predictions_mod1a_test)

MSE_mod1a_test = mean((observed_test - predictions_mod1a_test)^2) 



## do model 2 based on drop(mod1a) outcome


mod2a <- DirichReg(Y ~ incumbent_pct_FF + incumbent_pct_GP_LAB_SD + incumbent_pct_SF + candidates_per_seat_All_Others + candidates_per_seat_FF + candidates_per_seat_GP_LAB_SD + female_pct_GP_LAB_SD + Catholic_pct + Irish_over3_pct + Irish_Daily_And_In_Educ_pct + UK_birth_pct + pct_share_party_prior_election_FG + pct_share_party_prior_election_SF, data = DF, model = "alternative")

mod2a

summary(mod2a)

drop1(mod2a)

# do an R squared statsitic

predictions_mod2a <- predict(mod2a)

observed = DF$Y

rsq <- function (x, y) cor(x, y) ^ 2

rsq(observed, predictions_mod2a)

MSE_mod1a = mean((observed - predictions_mod2a)^2) 

# R squared on test

predictions_mod2a_test <- predict(mod2a, DFt)

rsq(observed_test, predictions_mod2a_test)

MSE_mod1b_test = mean((observed_test - predictions_mod2a_test)^2) 



DFt$Y <- DR_data(DFt[c(3,4,5,6,7)])

observed_test2 <- DFt$Y

observed_test2 <- DFt[c(3,4,5,6,7)]

MSE_mod1b_test_1 = mean((observed_test[c(1)] - predictions_mod2a_test[c(1)])^2) 
MSE_mod1b_test_2 = mean((observed_test[c(2)] - predictions_mod2a_test[c(2)])^2) 
MSE_mod1b_test_3 = mean((observed_test[c(3)] - predictions_mod2a_test[c(3)])^2) 
MSE_mod1b_test_4 = mean((observed_test[c(4)] - predictions_mod2a_test[c(4)])^2) 
MSE_mod1b_test_5 = mean((observed_test[c(5)] - predictions_mod2a_test[c(5)])^2) 

MSE_mod1b_test_1
MSE_mod1b_test_2
MSE_mod1b_test_3
MSE_mod1b_test_4
MSE_mod1b_test_5

# last iteration - 'normal' paramterisation with best Mod2a models 


mod3 <- DirichReg(Y ~ candidates_per_seat_FF + candidates_per_seat_GP_LAB_SD + incumbent_pct_FF + candidates_per_seat_All_Others + pct_share_party_prior_election_FG, data = DF)

mod3

summary(mod3)

# do an R squared statsitic

predictions_mod3 <- predict(mod3)

observed = DF$Y

rsq <- function (x, y) cor(x, y) ^ 2

rsq(observed, predictions_mod3)

MSE_mod1a = mean((observed - predictions_mod3)^2) 


# R squared on test

predictions_mod3_test <- predict(mod3, DFt)

rsq(observed_test, predictions_mod3_test)

MSE_mod3_test = mean((observed_test - predictions_mod3_test)^2) 


#
moda <- DirichReg(Y ~ incumbent_pct_FF + incumbent_pct_GP_LAB_SD + incumbent_pct_SF + candidates_per_seat_All_Others + candidates_per_seat_FF + candidates_per_seat_GP_LAB_SD + female_pct_GP_LAB_SD + Catholic_pct + Irish_over3_pct + Irish_Daily_And_In_Educ_pct + UK_birth_pct + pct_share_party_prior_election_FG + pct_share_party_prior_election_SF, data = DF, model = "alternative", base = 5)

moda

summary(moda)