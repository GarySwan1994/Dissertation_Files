#### Codebook for data merging

### GS 2022


# create new dir for files

dir = getwd()

new_dir = paste(dir, "/new folder Irish Politics R File", sep ="")

dir.create(new_dir)

setwd(new_dir)


# Get list of needed packages 

needed_packages <- c("stringr", "dplyr", "gender", "ggplot2", "lubridate", "downloader", "read_xlsx")  

# get not installed packages
not_installed <- needed_packages[!(needed_packages %in% installed.packages()[ , "Package"])]   

# Install any uninstalled packages

if(length(not_installed)) install.packages(not_installed) 

# load packages

library(stringr)
library(dplyr)
library(gender)
library(ggplot2)
library(lubridate)
library(downloader)


# download files

download.file('https://github.com/GarySwan1994/Dissertation_Files/raw/main/PostMergeZip.zip', destfile = "PostMergeZip.zip")
unzip("PostMergeZip.zip")

# Begin work on the electoral data

# Create new polling party categories
# First do a two party one
# then do a five party one

DF_2020 <- read.csv("2020 Election Data Pre-Merge.csv")

DF_2020 <- DF_2020 %>%
  mutate(Two_party = case_when(
    Party == 'FF' ~ 'FFG',
    Party == 'FG' ~ 'FFG',
    Party != 'FG' ~ 'All Others'  ))

DF_2020 <- DF_2020 %>%
  mutate(Multi_party = case_when(
    Party == 'FF' ~ 'FF',
    Party == 'FG' ~ 'FG',
    Party == 'SF' ~ 'SF',
    Party == 'LAB' ~ 'Left',
    Party == 'GP' ~ 'Left',
    Party == 'SD' ~ 'Left',
    Party != 'FG' ~ 'All Others'  ))

DF_2020 %>%
group_by(Two_party, Multi_party) %>%
summarise(n=n())

DF_2020<-DF_2020 %>%
  mutate(Female_bool = case_when(
    gender == 'female' ~ 1,
    gender != 'female' ~ 0))

# get the number of seats per constituency

const_seat_2020 <-DF_2020 %>%
  group_by(Constituency) %>% 
  summarise(seats = max(Seat))

DF_2020 <- left_join(DF_2020, const_seat_2020)

## summarise first at five party level

Five_Party_2020 <- DF_2020 %>%
  group_by(Constituency, Multi_party) %>%
  summarise(FP_Votes = sum(Count.1), Candidates = n(), count_female = sum(Female_bool) , Count_Incumbents = sum(incumbent), No_seats = max(seats))

Five_Party_2020 <- Five_Party_2020 %>%
  mutate(incumbency_pct = Count_Incumbents / Candidates)

Five_Party_2020 <- Five_Party_2020 %>%
  mutate(cands_per_seat = Candidates / No_seats)


Five_Party_2020 <- Five_Party_2020 %>%
  mutate(female_pct = count_female / Candidates)

# then add in polling and prior election result data

Prior_results <- read.csv("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/Prior%20Election%20Results.csv")

Prior_results$Multi_party = Prior_results$Multi.party

Prior_results_2020 <- Prior_results %>%
  filter(Election == "Election_2020")

Prior_results_2020$Multi_party = Prior_results_2020$Multi.party

Five_Party_2020 <- left_join(Five_Party_2020, Prior_results_2020)

# add in census data

Census_2020 <- read.csv("2017 Boundary Census Data Pre-Merge.csv")

Census_2020 <- Census_2020[, c(2:3 ,806:824)]

Census_2020$Constituency <- Census_2020$GEOGDESC

Five_Party_2020 <- left_join(Five_Party_2020, Census_2020)

# Multi-party for 2016

# Create new polling party categories
# First do a two party one
# then do a five party one

DF_2016 <- read.csv("2016 Election Data Pre-Merge.csv")

DF_2016 <- DF_2016 %>%
  mutate(Two_party = case_when(
    Party == 'FF' ~ 'FFG',
    Party == 'FG' ~ 'FFG',
    Party != 'FG' ~ 'All Others'  ))

DF_2016 <- DF_2016 %>%
  mutate(Multi_party = case_when(
    Party == 'FF' ~ 'FF',
    Party == 'FG' ~ 'FG',
    Party == 'SF' ~ 'SF',
    Party == 'LAB' ~ 'Left',
    Party == 'GP' ~ 'Left',
    Party == 'SD' ~ 'Left',
    Party != 'FG' ~ 'All Others'  ))

DF_2016 %>%
  group_by(Two_party, Multi_party) %>%
  summarise(n=n())

DF_2016<-DF_2016 %>%
  mutate(Female_bool = case_when(
    gender == 'female' ~ 1,
    gender != 'female' ~ 0))

# get the number of seats per constituency

const_seat_2016 <-DF_2016 %>%
  group_by(Constituency) %>% 
  summarise(seats = max(Seat))

DF_2016 <- left_join(DF_2016, const_seat_2016)

## summarise first at five party level

Five_Party_2016 <- DF_2016 %>%
  group_by(Constituency, Multi_party) %>%
  summarise(FP_Votes = sum(Count.1), Candidates = n(), count_female = sum(Female_bool) , Count_Incumbents = sum(incumbent), No_seats = max(seats))

Five_Party_2016 <- Five_Party_2016 %>%
  mutate(incumbency_pct = Count_Incumbents / Candidates)

Five_Party_2016 <- Five_Party_2016 %>%
  mutate(cands_per_seat = Candidates / No_seats)


Five_Party_2016 <- Five_Party_2016 %>%
  mutate(female_pct = count_female / Candidates)

# then add in polling and prior election result data

Prior_results <- read.csv("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/Prior%20Election%20Results.csv")

Prior_results$Multi_party = Prior_results$Multi.party

Prior_results_2016 <- Prior_results %>%
  filter(Election == "Election_2016")

Prior_results_2016$Multi_party = Prior_results_2016$Multi.party

Five_Party_2016 <- left_join(Five_Party_2016, Prior_results_2016)

# add in census data

Census_2016 <- read.csv("2013 Boundary Census Data Pre-Merge.csv")

Census_2016 <- Census_2016[, c(3:4 ,806:829)]

Census_2016$Constituency <- Census_2016$GEOGDESC

Five_Party_2016 <- left_join(Five_Party_2016, Census_2016)

# do the two party dataset

## summarise first at five party level

Five_Party_2016 <- DF_2016 %>%
  group_by(Constituency, Multi_party) %>%
  summarise(FP_Votes = sum(Count.1), Candidates = n(), count_female = sum(Female_bool) , Count_Incumbents = sum(incumbent), No_seats = max(seats))

Five_Party_2016 <- Five_Party_2016 %>%
  mutate(incumbency_pct = Count_Incumbents / Candidates)

Five_Party_2016 <- Five_Party_2016 %>%
  mutate(cands_per_seat = Candidates / No_seats)


Five_Party_2016 <- Five_Party_2016 %>%
  mutate(female_pct = count_female / Candidates)

# then add in polling and prior election result data

Prior_results <- read.csv("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/Prior%20Election%20Results.csv")

Prior_results$Multi_party = Prior_results$Multi.party

Prior_results_2016 <- Prior_results %>%
  filter(Election == "Election_2016")

Prior_results_2016$Multi_party = Prior_results_2016$Multi.party

Five_Party_2016 <- left_join(Five_Party_2016, Prior_results_2016)

# add in census data

Census_2016 <- read.csv("2013 Boundary Census Data Pre-Merge.csv")

Census_2016 <- Census_2016[, c(3:4 ,806:824)]

Census_2016$Constituency <- Census_2016$GEOGDESC

Five_Party_2016 <- left_join(Five_Party_2016, Census_2016)

## summarise first at five party level

Five_Party_2016 <- DF_2016 %>%
  group_by(Constituency, Multi_party) %>%
  summarise(FP_Votes = sum(Count.1), Candidates = n(), count_female = sum(Female_bool) , Count_Incumbents = sum(incumbent), No_seats = max(seats))

Five_Party_2016 <- Five_Party_2016 %>%
  mutate(incumbency_pct = Count_Incumbents / Candidates)

Five_Party_2016 <- Five_Party_2016 %>%
  mutate(cands_per_seat = Candidates / No_seats)


Five_Party_2016 <- Five_Party_2016 %>%
  mutate(female_pct = count_female / Candidates)

# then add in polling and prior election result data

Prior_results <- read.csv("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/Prior%20Election%20Results.csv")

Prior_results$Multi_party = Prior_results$Multi.party

Prior_results_2016 <- Prior_results %>%
  filter(Election == "Election_2016")

Prior_results_2016$Multi_party = Prior_results_2016$Multi.party

Five_Party_2016 <- left_join(Five_Party_2016, Prior_results_2016)

# add in census data

Census_2016 <- read.csv("2013 Boundary Census Data Pre-Merge.csv")

Census_2016 <- Census_2016[, c(3:4 ,806:824)]

Census_2016$Constituency <- Census_2016$GEOGDESC

Five_Party_2016 <- left_join(Five_Party_2016, Census_2016)

## do the two party dataset - 2016

Two_Party_2016 <- DF_2016 %>%
  group_by(Constituency, Two_party) %>%
  summarise(FP_Votes = sum(Count.1), Candidates = n(), count_female = sum(Female_bool) , Count_Incumbents = sum(incumbent), No_seats = max(seats))

Two_Party_2016 <- Two_Party_2016 %>%
  mutate(incumbency_pct = Count_Incumbents / Candidates)

Two_Party_2016 <- Two_Party_2016 %>%
  mutate(cands_per_seat = Candidates / No_seats)

Two_Party_2016 <- Two_Party_2016 %>%
  mutate(female_pct = count_female / Candidates)

# then add in polling and prior election result data

Prior_results <- read.csv("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/Prior%20Election%20Results.csv")

Prior_results= Prior_results  %>%  
  mutate(Two_party  = case_when(
  Multi.party == 'FF' ~ 'FFG',
  Multi.party == 'FG' ~ 'FFG',
  Multi.party != 'FG' ~ 'All Others' ))

Prior_results_2016 <- Prior_results %>%
  filter(Election == "Election_2016") %>%
  group_by(Two_party, Constituency) %>%
  summarise(FP_Share_Plus_Polls_Recent = sum(FP_Share_Plus_Polls_Recent))

Two_Party_2016 <- left_join(Two_Party_2016, Prior_results_2016)

# add in census data

Census_2016 <- read.csv("2013 Boundary Census Data Pre-Merge.csv")

Census_2016 <- Census_2016[, c(3:4 ,806:824)]

Census_2016$Constituency <- Census_2016$GEOGDESC

Two_Party_2016 <- left_join(Two_Party_2016, Census_2016)


## do the two party dataset - 2020


Two_Party_2020 <- DF_2020 %>%
  group_by(Constituency, Two_party) %>%
  summarise(FP_Votes = sum(Count.1), Candidates = n(), count_female = sum(Female_bool) , Count_Incumbents = sum(incumbent), No_seats = max(seats))

Two_Party_2020 <- Two_Party_2020%>%
  mutate(incumbency_pct = Count_Incumbents / Candidates)

Two_Party_2020 <- Two_Party_2020 %>%
  mutate(cands_per_seat = Candidates / No_seats)

Two_Party_2020 <- Two_Party_2020 %>%
  mutate(female_pct = count_female / Candidates)

# then add in polling and prior election result data

Prior_results <- read.csv("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/Prior%20Election%20Results.csv")

Prior_results= Prior_results  %>%  
  mutate(Two_party  = case_when(
    Multi.party == 'FF' ~ 'FFG',
    Multi.party == 'FG' ~ 'FFG',
    Multi.party != 'FG' ~ 'All Others' ))

Prior_results_2020 <- Prior_results %>%
  filter(Election == "Election_2020") %>%
  group_by(Two_party, Constituency) %>%
  summarise(FP_Share_Plus_Polls_Recent = sum(FP_Share_Plus_Polls_Recent))

Two_Party_2020 <- left_join(Two_Party_2020, Prior_results_2020)

# add in census data

Census_2020 <- read.csv("2017 Boundary Census Data Pre-Merge.csv")

Census_2020 <- Census_2020[, c(2:3 ,806:824)]

Census_2020$Constituency <- Census_2020$GEOGDESC

Two_Party_2020 <- left_join(Two_Party_2020, Census_2020)