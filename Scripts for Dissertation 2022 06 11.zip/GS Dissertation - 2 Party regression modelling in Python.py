# -*- coding: utf-8 -*-
"""
Created on Sat Mar 19 18:01:18 2022

@author: Gary Swan

@Title: .py file with 'traditonal' machine learning regression approachs
"""


## Load the packages

import os 

import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn import preprocessing

from sklearn.model_selection import GridSearchCV

from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix 

from sklearn.linear_model import LinearRegression as Reg
from sklearn.svm import SVC as SVC
from sklearn.svm import SVR as SVR
from sklearn.ensemble import RandomForestRegressor as RFR
from sklearn.ensemble import RandomForestClassifier as RFC
from sklearn.tree import DecisionTreeClassifier as DTC
from sklearn.tree import DecisionTreeRegressor as DTR

from sklearn.neighbors import KNeighborsClassifier as kNN
from sklearn.naive_bayes import  GaussianNB as GNB, CategoricalNB as CNB
from sklearn.linear_model import Lasso

from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import SelectKBest, chi2, mutual_info_classif
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score

## Load the training data

DF = pd.read_csv('https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/2party_model%20reduced%20featureset%202022%2005%2015.csv', encoding = 'cp1252') # load the CSV

Constituency = pd.DataFrame(DF.pop('Constituency'))


y = DF.pop('FP_Share').values

X = DF

feature_names = DF.columns

# load test data

DF_test_red = pd.read_csv('https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/2party_model%20reduced%20featureset%202022%2005%2015%20TEST%20DATA.csv', encoding = 'cp1252') # load the CSV

Constituency_test = DF_test_red.pop('Constituency')

yTest_red = DF_test_red.pop('FP_Share').values

XTest_red = DF_test_red



## scaling Everything, Everywhere, All at Once

# create one df

X_all = X.append(XTest_red)
min_max_scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))
X_all = pd.DataFrame(min_max_scaler.fit_transform(X_all))

# split back to test and train sets

X = X_all.loc[0:39]
XTest_red = X_all.loc[40:79]


min_max_scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))
X = pd.DataFrame(min_max_scaler.fit_transform(DF))
XTest_red = pd.DataFrame(min_max_scaler.fit_transform(DF_test_red))

                                                                                                        
## Lets do a GridSearch

Lasso_ = Lasso()

Lasso_.get_params()


param_grid_Lasso = {'alpha': [1, 0.2, 0.1, 0.05, 0.01,0.00001], 'max_iter': [10000, 100000, 100000000, 1000000000]   ,
             'selection':['cyclic', 'random'],
              'fit_intercept':[False]}

Lasso_gs = GridSearchCV(Lasso_,param_grid_Lasso, 
                      verbose = 5, n_jobs = -1 )

Lasso_gs = Lasso_gs.fit(X, y)

Lasso_gs.best_params_

Lasso_gs.score(X, y)

Lasso_predict = pd.DataFrame(Lasso_gs.predict(X))
Lasso_train_R_Sq = r2_score(Lasso_predict , y)
print(Lasso_train_R_Sq)

Lasso_gs.summary()


# MSE

from sklearn.metrics import mean_squared_error

Lasso_mse = mean_squared_error(y, Lasso_predict)
Lasso_mse

# get feature importance for LASSO

array = Lasso_gs.best_estimator_.coef_
feat_imp = zip(*sorted(zip(array,feature_names)))
print(set(feat_imp))


# LASSO without GS CV

Lasso_Reg = Lasso(alpha = 0.01, selection = 'random',  max_iter = 1000000000, fit_intercept = False)

Lasso_Reg = Lasso_Reg.fit(X, y)

Lasso_Reg.score(X, y)

from sklearn.feature_selection import f_regression
freg=f_regression(X, y)

p=freg[1]

print(p.round(3))

import statsmodels.api as sm

logit_model=sm.Logit(y,X)

result=logit_model.fit()
print(result.summary())


Lasso_Reg_predict = pd.DataFrame(Lasso_Reg.predict(X))
Lasso_Reg_R_Sq = r2_score(Lasso_Reg_predict , y)
print(Lasso_Reg_R_Sq)


coeffs = Lasso_Reg.coef_

feat_coeffs = zip(*sorted(zip(coeffs,feature_names)))
print(set(feat_coeffs))


'''

1 - (1-Lasso_gs.score(X, y))*(len(y)-1)/(len(y)-X.shape[1]-1)

# adjusted r squared

1 - (1-Lasso_train_R_Sq)*(len(y)-1)/(len(y)-X.shape[1]-1)
'''
#SVR

SVR_ = SVR()

SVR_.get_params()


param_grid_svr = {'kernel':['poly', 'linear', 'rbf'],    
              'C': [0.1, 1, 10, 100, 1000], 
             'shrinking':[1,0],
             'gamma': ['scale','auto'],
             'epsilon':[1, 0.1, 0.01, 0.001, 0.0001]}


SVR_gs = GridSearchCV(SVR(),param_grid_svr,cv=10,  
                      verbose = 5, n_jobs = -1)

# fit the model

SVR_gs.fit(X, y)

SVR_gs.best_params_

SVR_gs.score(X, y)

SVR_score = SVR_gs.score(X, y)

SVR_predict = pd.DataFrame(SVR_gs.predict(X))
SVR_train_R_Sq = r2_score(SVR_predict , y)
print(SVR_train_R_Sq)


Lasso_mse = mean_squared_error(y, SVR_predict)
Lasso_mse

array = SVR_gs.best_estimator_.coef_

def f_importances(coef, names):
    imp = coef
    feat_imp = zip(*sorted(zip(imp,names)))
    print(set(feat_imp))

f_importances(array, feature_names)


## linear kernel only

param_grid_svr2 = {'kernel':['linear'],    
              'C': [0.1, 1, 10, 100, 1000], 
             'shrinking':[1,0],
             'gamma': ['scale','auto'],
             'epsilon':[1, 0.1, 0.01, 0.001, 0.0001]}


SVR_gs2 = GridSearchCV(SVR(),param_grid_svr2,cv=10,  
                      verbose = 5, n_jobs = -1)

# fit the model

SVR_gs2.fit(X, y)

SVR_gs2.best_params_

SVR_gs2.score(X, y)

SVR_predict_test2 = pd.DataFrame(SVR_gs2.predict(X))


SVR_train_R_Sq2 = r2_score(SVR_predict_test2 , y)
print(SVR_train_R_Sq2)

array = SVR_gs2.best_estimator_.coef_

f_importances(array, feature_names)

### linear only leads to a small loss in accuracy - cool!

from matplotlib import pyplot as pylt

feat_imp = []

def f_importances(coef, names):
    imp = coef
    feat_imp = zip(*sorted(zip(imp,names)))
    print(feat_imp)

f_importances(SVR_lin_gs.best_estimator_.coef_, feature_names)

SVR_lin_gs.best_estimator_.coef_



#random forest regressor


RF = RFR()

#RF.get_params()

param_grid_RF = {'min_samples_leaf': [1,3,5],    
              'max_features': ['auto', 'sqrt', 'log2'],
              'random_state' : [42]}

RF_gs = GridSearchCV(RF,param_grid_RF ,cv=10,  
                      verbose = 5, n_jobs = -1)

RF_gs.fit(X, y)

RF_gs.best_params_
RF_gs.score(X, y)

RF_gs_predict = pd.DataFrame(RF_gs.predict(X))


RF_train_R_Sq = r2_score(RF_gs_predict , y)
print(RF_train_R_Sq )

RF_mse = mean_squared_error(y, RF_gs_predict)
RF_mse

#RFR feature importance 

forest = RFR(min_samples_leaf = 1, max_features = 'auto', random_state = 42)
forest.fit(X, y)
forest.score(X, y)


#get importance values

importances = forest.feature_importances_

from matplotlib import pyplot as pylt

feat_imp = []

def f_importances(coef, names):
    imp = coef
    feat_imp = zip(*sorted(zip(imp,names)))
    print(set(feat_imp))

f_importances(importances, feature_names)


## NN


from sklearn.neural_network import MLPRegressor

mlp = MLPRegressor()


param_grid_mlp = {'hidden_layer_sizes': [5,10,20],    
              'activation': ['identity', 'logistic', 'tanh', 'relu'], 
             'solver':['lbfgs', 'sgd', 'adam'],
             'alpha': [0.01, 0.001,0.0001,0.00001],
             'learning_rate':['constant', 'invscaling', 'adaptive'], 'max_iter':[1000],
             'random_state':[42]}

mlp_gs = GridSearchCV(mlp,param_grid_mlp,cv=10,  
                      verbose = 5, n_jobs = -1)

mlp_gs.fit(X, y)

mlp_gs.best_params_

mlp_gs.score(X, y)

MLP_predict = pd.DataFrame(mlp_gs.predict(X))

mlp_train_R_Sq = r2_score(MLP_predict , y)
print(mlp_train_R_Sq )

mlp_mse = mean_squared_error(y, MLP_predict)
mlp_mse

# random forest


RF_gs.fit(X_red, y)

RF_gs.best_params_
RF_gs.score(X_red, y)
RF_gs_predict_test = pd.DataFrame(RF_gs.predict(X))

                                                                                
# do test scoring
                                                                                       ''''''
print(SVR_gs.score(XTest_red, yTest_red))

print(mlp_gs.score(XTest_red, yTest_red))

print(RF_gs.score(XTest_red, yTest_red))

print(Lasso_gs.score(XTest_red, yTest_red))



RF_gs_predict_test = pd.DataFrame(RF_gs.predict(XTest_red))

RF_R_Sq = r2_score(RF_gs_predict_test , yTest_red)
print(RF_R_Sq )


SVR_gs_predict_test = pd.DataFrame(SVR_gs.predict(XTest_red))

SVR_R_Sq = r2_score(SVR_gs_predict_test , yTest_red)
print(SVR_R_Sq )

mlp_gs_predict_test = pd.DataFrame(mlp_gs.predict(XTest_red))

mlp_R_Sq = r2_score(mlp_gs_predict_test , yTest_red)
print(mlp_R_Sq )

Lasso_gs_predict_test = pd.DataFrame(Lasso_gs.predict(XTest_red))

LASSO_R_Sq = r2_score(Lasso_gs_predict_test, yTest_red)
print(LASSO_R_Sq )

SVR_gs2_predict_test = pd.DataFrame(SVR_gs2.predict(XTest_red))

SVR_gs2_R_Sq = r2_score(SVR_gs2_predict_test, yTest_red)
print(SVR_gs2_R_Sq )


# MSE

SVR_test_mse = mean_squared_error(SVR_gs_predict_test , yTest_red)
SVR_test_mse


mlp_test_mse = mean_squared_error(mlp_gs_predict_test , yTest_red)
mlp_test_mse


Lasso_test_mse = mean_squared_error(Lasso_gs_predict_test , yTest_red)
Lasso_test_mse

RF_test_mse = mean_squared_error(RF_gs_predict_test , yTest_red)
RF_test_mse

# export results

Results_Train_DF = pd.concat([Constituency, Lasso_predict, SVR_predict , RF_gs_predict , MLP_predict], axis = 1)

Results_Train_DF.columns = ("Constituency", "Lasso_predict","SVR_predict", "RF_gs_predict"  , "MLP_predict")

Results_Train_DF.to_csv("Results 2 Party Train.csv")

Results_Test_DF = pd.concat([Constituency_test, Lasso_gs_predict_test, SVR_gs_predict_test ,  RF_gs_predict_test , mlp_gs_predict_test], axis = 1)

Results_Test_DF.columns = ("Constituency", "Lasso_gs_predict_test", "SVR_gs_predict_test" ,  "RF_gs_predict_test", "mlp_gs_predict_test")

Results_Test_DF.to_csv("Results 2 Party Test.csv")
 
# load test data with a more "realistic" polling swing

# i want to test how much model accuracy depends on this one piece of data


# load test data

DF_test_red2 = pd.read_csv('2party_model reduced featureset 2022 05 15 TEST DATA POLL hypothethical.csv', encoding = 'cp1252') # load the CSV

DF_test_red2.pop('Constituency')

yTest_red2 = DF_test_red2.pop('FP_Share').values

XTest_red2 = DF_test_red2

## scaling Everything, Everywhere, All at Once

XTest_red = DF_test_red

# create one df

X_all = X.append(XTest_red2)
min_max_scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))
X_all = pd.DataFrame(min_max_scaler.fit_transform(X_all))

# split back to test and train sets

X = X_all.loc[0:39]
XTest_red2 = X_all.loc[40:79]

                                                                                                                                
SVR_gs_predict_test2 = pd.DataFrame(SVR_gs.predict(XTest_red2))

RF_gs_predict_test2 = pd.DataFrame(RF_gs.predict(XTest_red2))
mlp_gs_predict_test2 = pd.DataFrame(mlp_gs.predict(XTest_red2))
Lasso_gs_predict_test2 = pd.DataFrame(Lasso_gs.predict(XTest_red2))



RF_R_Sq2 = r2_score(RF_gs_predict_test2 , yTest_red2)
print(RF_R_Sq2 )

SVR_R_Sq2 = r2_score(SVR_gs_predict_test2 , yTest_red2)
print(SVR_R_Sq2 )


mlp_R_Sq2 = r2_score(mlp_gs_predict_test2 , yTest_red2)
print(mlp_R_Sq2 )

LASSO_R_Sq2 = r2_score(Lasso_gs_predict_test2, yTest_red2)
print(LASSO_R_Sq2 )

X = DF


# try linear kernel

param_grid_svr_lin = {'kernel':['linear'],    
              'C': [0.1, 1, 10, 100, 1000], 
             'shrinking':[1,0],
             'gamma': ['scale','auto'],
             'epsilon':[1, 0.1, 0.01, 0.001, 0.0001]}


SVR_lin_gs = GridSearchCV(SVR(),param_grid_svr_lin,cv=10,  
                      verbose = 5, n_jobs = -1)


# fit the model

SVR_lin_gs.fit(X, y)

SVR_lin_gs.best_params_

SVR_lin_gs.score(X, y)

# run lasso withotu GS CV

