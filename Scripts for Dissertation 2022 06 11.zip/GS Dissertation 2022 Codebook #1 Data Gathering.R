#### Codebook for data gathering and preparation

### GS 2022

setwd("C:/Users/35385/Documents")

dir = getwd()

new_dir = paste(dir, "/new folder Irish Politics R File", sep ="")

dir.create(new_dir)

setwd(new_dir)

## Data Gathering

# Get list of needed packages 

needed_packages <- c("stringr", "dplyr", "gender", "ggplot2", "lubridate", "downloader", "read_xlsx")  

# get not installed packages
not_installed <- needed_packages[!(needed_packages %in% installed.packages()[ , "Package"])]   

# Install any uninstalled packages

if(length(not_installed)) install.packages(not_installed) 

# load packages

library(stringr)
library(dplyr)
library(gender)
library(ggplot2)
library(lubridate)
library(downloader)

###setwd("C:/Users/35385/Documents/College/Dissertation/Datasets/new test")    ~ ~ ~ ~ ~ ~ ~

# get list of all files matching the pattern (CSV) in current directory

download.file('https://github.com/GarySwan1994/Dissertation_Files/raw/main/2020_webscrape_files.zip', destfile = "2020_webscrape_files.zip")
unzip ("2020_webscrape_files.zip")


files <- list.files(pattern = "\\.csv$")


# creates an empty data frame for merging files into

DF <- data.frame(matrix(ncol = 21, nrow = 0))

#provide column names

download.file("https://github.com/GarySwan1994/Dissertation_Files/raw/main/example%20headers.xlsx", destfile = "example headers.xlsx", mode="wb")

example_df <- readxl::read_xlsx("example headers.xlsx")

colnames(DF) <- colnames(example_df)

# Merges all files into a single table

#reading each file within the range and append them to create one file

for (f in files){
  df <- read.csv(f)      # read the file
  DF <- rbind(DF,df)     # append file

}

## replace unknown chars in candidate names

DF$Candidate <- gsub('ó', '�', DF$Candidate)
DF$Candidate <- gsub('á', '�', DF$Candidate)  
DF$Candidate <- gsub('��', '�', DF$Candidate) 
DF$Candidate <- gsub('�"', '�', DF$Candidate)
DF$Candidate <- gsub('é', '�', DF$Candidate)
DF$Candidate <- gsub('�"', '�', DF$Candidate)
DF$Candidate <- gsub('�-', '�', DF$Candidate)
DF$Candidate <- gsub('�s', '�', DF$Candidate)
DF$Candidate <- gsub('�"', '�', DF$Candidate)
DF$Candidate <- gsub('�', '�', DF$Candidate)
DF$Candidate <- gsub('�"', '�', DF$Candidate)


# The below code allows us to clean each count column down to the transfer votes only
# repeat for counts 2 -15
# then can be additive to get the total votes

DF$Count.2 <- ifelse(nchar(DF$Count.2)==0, "(0)", DF$Count.2)  ## If the column is blank, insert (0)

DF$Count.2 <- str_extract_all(DF$Count.2, "\\([^()]+\\)") #extract whats in the brackets



DF$Count.2 <- gsub( ")", "", DF$Count.2) #gets rid of ")" char

DF$Count.2 <- gsub( "\\(", "", DF$Count.2) #gets rid of "(" char
DF$Count.2 <- str_replace(DF$Count.2, "character(0)", "0") ##Replace character(0), not working currently


## 3 

DF$Count.3 <- ifelse(nchar(DF$Count.3)==0, "(0)", DF$Count.3)  ## If the column is blank, insert (0)

DF$Count.3 <- str_extract_all(DF$Count.3, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.3 <- gsub( ")", "", DF$Count.3) #gets rid of ")" char

DF$Count.3 <- gsub( "\\(", "", DF$Count.3) #gets rid of "(" char
DF$Count.3 <- str_replace(DF$Count.3, "character(0)", "0") ##Replace character(0), not working currently


## 4

DF$Count.4 <- ifelse(nchar(DF$Count.4)==0, "(0)", DF$Count.4)  ## If the column is blank, insert (0)

DF$Count.4 <- str_extract_all(DF$Count.4, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.4 <- gsub( ")", "", DF$Count.4) #gets rid of ")" char

DF$Count.4 <- gsub( "\\(", "", DF$Count.4) #gets rid of "(" char
DF$Count.4 <- str_replace(DF$Count.4, "character(0)", "0") ##Replace character(0), not working currently

## 5 

DF$Count.5 <- ifelse(nchar(DF$Count.5)==0, "(0)", DF$Count.5)  ## If the column is blank, insert (0)

DF$Count.5 <- str_extract_all(DF$Count.5, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.5 <- gsub( ")", "", DF$Count.5) #gets rid of ")" char

DF$Count.5 <- gsub( "\\(", "", DF$Count.5) #gets rid of "(" char
DF$Count.5 <- str_replace(DF$Count.5, "character(0)", "0") ##Replace character(0), not working currently


# 6

DF$Count.6 <- ifelse(nchar(DF$Count.6)==0, "(0)", DF$Count.6)  ## If the column is blank, insert (0)

DF$Count.6 <- str_extract_all(DF$Count.6, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.6 <- gsub( ")", "", DF$Count.6) #gets rid of ")" char

DF$Count.6 <- gsub( "\\(", "", DF$Count.6) #gets rid of "(" char
DF$Count.6 <- str_replace(DF$Count.6, "character(0)", "0") ##Replace character(0), not working currently


## 7

DF$Count.7 <- ifelse(nchar(DF$Count.7)==0, "(0)", DF$Count.7)  ## If the column is blank, insert (0)

DF$Count.7 <- str_extract_all(DF$Count.7, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.7 <- gsub( ")", "", DF$Count.7) #gets rid of ")" char

DF$Count.7 <- gsub( "\\(", "", DF$Count.7) #gets rid of "(" char
DF$Count.7 <- str_replace(DF$Count.7, "character(0)", "0") ##Replace character(0), not working currently


# 8 

DF$Count.8 <- ifelse(nchar(DF$Count.8)==0, "(0)", DF$Count.8)  ## If the column is blank, insert (0)

DF$Count.8 <- str_extract_all(DF$Count.8, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.8 <- gsub( ")", "", DF$Count.8) #gets rid of ")" char

DF$Count.8 <- gsub( "\\(", "", DF$Count.8) #gets rid of "(" char
DF$Count.8 <- str_replace(DF$Count.8, "character(0)", "0") ##Replace character(0), not working currently


## 9
DF$Count.9 <- ifelse(nchar(DF$Count.9)==0, "(0)", DF$Count.9)  ## If the column is blank, insert (0)

DF$Count.9 <- str_extract_all(DF$Count.9, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.9 <- gsub( ")", "", DF$Count.9) #gets rid of ")" char

DF$Count.9 <- gsub( "\\(", "", DF$Count.9) #gets rid of "(" char
DF$Count.9 <- str_replace(DF$Count.9, "character(0)", "0") ##Replace character(0), not working currently


## 10
DF$Count.10 <- ifelse(nchar(DF$Count.10)==0, "(0)", DF$Count.10)  ## If the column is blank, insert (0)

DF$Count.10 <- str_extract_all(DF$Count.10, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.10 <- gsub( ")", "", DF$Count.10) #gets rid of ")" char

DF$Count.10 <- gsub( "\\(", "", DF$Count.10) #gets rid of "(" char
DF$Count.10 <- str_replace(DF$Count.10, "character(0)", "0") ##Replace character(0), not working currently


##11
DF$Count.11 <- ifelse(nchar(DF$Count.11)==0, "(0)", DF$Count.11)  ## If the column is blank, insert (0)

DF$Count.11 <- str_extract_all(DF$Count.11, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.11 <- gsub( ")", "", DF$Count.11) #gets rid of ")" char

DF$Count.11 <- gsub( "\\(", "", DF$Count.11) #gets rid of "(" char
DF$Count.11 <- str_replace(DF$Count.11, "character(0)", "0") ##Replace character(0), not working currently


#12 
DF$Count.12 <- ifelse(nchar(DF$Count.12)==0, "(0)", DF$Count.12)  ## If the column is blank, insert (0)

DF$Count.12 <- str_extract_all(DF$Count.12, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.12 <- gsub( ")", "", DF$Count.12) #gets rid of ")" char

DF$Count.12 <- gsub( "\\(", "", DF$Count.12) #gets rid of "(" char

DF$Count.12 <- str_replace(DF$Count.12, "character(0)", "0") ##Replace character(0), not working currently

## 13
DF$Count.13 <- ifelse(nchar(DF$Count.13)==0, "(0)", DF$Count.13)  ## If the column is blank, insert (0)

DF$Count.13 <- str_extract_all(DF$Count.13, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.13 <- gsub( ")", "", DF$Count.13) #gets rid of ")" char

DF$Count.13 <- gsub( "\\(", "", DF$Count.13) #gets rid of "(" char
DF$Count.13 <- str_replace(DF$Count.13, "character(0)", "0") ##Replace character(0), not working currently


## 14
DF$Count.14 <- ifelse(nchar(DF$Count.14)==0, "(0)", DF$Count.14)  ## If the column is blank, insert (0)

DF$Count.14 <- str_extract_all(DF$Count.14, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.14 <- gsub( ")", "", DF$Count.14) #gets rid of ")" char

DF$Count.14 <- gsub( "\\(", "", DF$Count.14) #gets rid of "(" char
DF$Count.14 <- str_replace(DF$Count.14, "character(0)", "0") ##Replace character(0), not working currently


#15
DF$Count.15 <- ifelse(nchar(DF$Count.15)==0, "(0)", DF$Count.15)  ## If the column is blank, insert (0)

DF$Count.15 <- str_extract_all(DF$Count.15, "\\([^()]+\\)") #extract whats in the brackets

DF$Count.15 <- gsub( ")", "", DF$Count.15) #gets rid of ")" char

DF$Count.15 <- gsub( "\\(", "", DF$Count.15) #gets rid of "(" char

DF$Count.15 <- str_replace(DF$Count.15, "character(0)", "0") ##Replace character(0), not working currently

### DATA CLEANING AND TRANSFORMATIONS ###

# get the constituency from the scraping url


download.file("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/const_scrape_url_mapping2020.csv", destfile = "const_scrape_url_mapping2020.csv", mode="wb")

const_mapping_2020 <- read.csv("const_scrape_url_mapping2020.csv")

DF <- left_join(DF, const_mapping_2020)

#replace NA with 0 in seat column

DF$Seat[is.na(DF$Seat)] <- 0
DF$Count.1[is.na(DF$Count.1)] <- 0


# Get party affiliation from candidate name
# This uses regex within the str_extract_all function to take everything within "(**)" out

DF$Party <- str_extract_all(DF$Candidate, "\\([^()]+\\)")
DF$Count.15 <- str_replace(DF$Count.15, "character(0)", "0") ##Replace character(0), not working currently

# Get total votes in first round for each constituency

DF_const_summ <- DF %>% 
  group_by(Constituency) %>%
  summarise(n=n(), total_const_vote = sum(Count.1), seats = max(Seat))

DF_const_summ$Quota = ceiling(DF_const_summ$total_const_vote / (DF_const_summ$seats+1)) 

# Merge in constituency info

DF <- left_join(DF, DF_const_summ, by = c("Constituency"))

is.na(DF$Quota)

# get total transfers

DF$Count.2<-as.numeric(DF$Count.2)
DF$Count.3<-as.numeric(DF$Count.3)
DF$Count.4<-as.numeric(DF$Count.4)
DF$Count.5<-as.numeric(DF$Count.5)
DF$Count.6<-as.numeric(DF$Count.6)
DF$Count.7<-as.numeric(DF$Count.7)
DF$Count.8<-as.numeric(DF$Count.8)
DF$Count.9<-as.numeric(DF$Count.9)
DF$Count.10<-as.numeric(DF$Count.10)
DF$Count.11<-as.numeric(DF$Count.11)
DF$Count.12<-as.numeric(DF$Count.12)
DF$Count.13<-as.numeric(DF$Count.13)
DF$Count.14<-as.numeric(DF$Count.14)
DF$Count.15<-as.numeric(DF$Count.15)

DF$Total_Transfers = (DF$Count.2+DF$Count.3+DF$Count.4+DF$Count.5+DF$Count.6+DF$Count.7+DF$Count.8+DF$Count.9+DF$Count.10+DF$Count.11+DF$Count.12+DF$Count.13+DF$Count.14+DF$Count.15)

# Get votes as %of Quota

DF$FP_Quota_pct <- DF$Count.1 / DF$Quota

DF$Trans_Quota_pct <- DF$Total_Transfers / DF$Quota

# Elected flag

DF <- DF %>%
  mutate(Elected = case_when(
    Seat > 0 ~ 1,
    Seat < 1 ~ 0
  ))

DF[1] <- NULL
DF$Count.x <- NULL

## use the gender package to predict candidate sex


Names <- word(DF$Candidate, 1)
DF$First_Name <- word(DF$Candidate, 1)

Candidate_Gender_Kantrowitz = gender(Names, method = "kantrowitz")
Candidate_Gender_genderize = gender(Names, method = "genderize") # API limited - be careful!

Candidate_Gender_Kantrowitz
Candidate_Gender_genderize # this one covers all names

Candidate_Gender_genderize_close <- Candidate_Gender_genderize %>%
  filter(proportion_female < 0.7, proportion_female > 0.3)

Candidate_Detail_Gender_Close <- left_join(Candidate_Gender_genderize_close, DF, by = c("name" = "First_Name"))

Candidate_Gender_genderize <- Candidate_Gender_genderize %>%
  mutate(gender = case_when(
    name == 'Dara' ~ 'male',
    name == 'Dessie' ~ 'male',
    name == 'Joan' ~ 'female',
    name == 'Emer' ~ 'female',
    name == 'T.P.' ~ 'male',
    name == 'Se�n' ~ 'male',
    name == 'P�draig' ~ 'male',
    name == 'Aindrias' ~ 'male',
    name == 'Ciar�n' ~ 'male',
    name == 'Miche�l' ~ 'male',
    name == 'Aodh�n' ~ 'male',
    name == 'Oghenetano' ~ 'male',
    name == 'Deagl�n' ~ 'male',
    name == '�amon' ~ 'male',
    name == 'n�all' ~ 'male',
    name == 'Ruair�' ~ 'male',
    name == 'Daith�' ~ 'male',
    name == 'Seighin' ~ 'male',
    TRUE ~ gender) )

Candidate_Gender_genderize_old <- Candidate_Gender_genderize 

Candidate_Gender_genderize_distinct <- Candidate_Gender_genderize %>%
  distinct(.keep_all = TRUE)

DF$gender <- NULL
DF$proportion_male <- NULL
DF$proportion_female <- NULL

DF <- left_join(DF, Candidate_Gender_genderize_distinct, by = c("First_Name"="name"))

# tidy up names not covered in genderize
# try kantrowitz

DF_NA <- DF[is.na(DF$gender),]

DF <- DF %>%
  mutate(gender = case_when(
    !is.na(gender) ~ gender,
    TRUE ~ 'female'
  ))

DF <- DF %>%
  mutate(gender = case_when(
    First_Name == 'T.P.' ~ 'male',
    First_Name == 'Se�n' ~ 'male',
    First_Name == 'P�draig' ~ 'male',
    First_Name == 'Aindrias' ~ 'male',
    First_Name == 'Ciar�n' ~ 'male',
    First_Name == 'Miche�l' ~ 'male',
    First_Name == 'Aodh�n' ~ 'male',
    First_Name == 'Oghenetano' ~ 'male',
    First_Name == 'Deagl�n' ~ 'male',
    First_Name == '�amon' ~ 'male',
    First_Name == 'N�all' ~ 'male',
    First_Name == 'Ruair�' ~ 'male',
    First_Name == 'Daith�' ~ 'male',
    First_Name == 'Seighin' ~ 'male',
    is.na(gender) ~ 'female',
    TRUE ~ gender  )) 

#Clean data in DF

DF <- DF %>%
  mutate(Candidate = case_when(
    Candidate == 'Eoin �Broin' ~ 'Eoin �Broin',
    Candidate == 'Aodh�n �R�ord�in'~ 'Aodh�n �R�ord�in',
    Candidate == 'Aengus �Snodaigh'~ 'Aengus �Snodaigh',
    TRUE ~ Candidate
      ))

### repeat this process, but for the 2016 dataset

download.file('https://github.com/GarySwan1994/Dissertation_Files/raw/main/2016_webscrape_files.zip', destfile = "2016_webscrape_files.zip")
unzip ("2016_webscrape_files.zip")


files <- list.files(pattern = "*election.csv")
files2 <- list.files(pattern = "*16.csv")

files = append(files, files2)

# creates an empty data frame for merging files into

DF_16 <- data.frame(matrix(ncol = 21, nrow = 0))

#provide column names

colnames(DF_16) <- colnames(example_df)


# Merges all files into a single table

#reading each file within the range and append them to create one file

for (f in files){
  df <- read.csv(f)      # read the file
  DF_16 <- rbind(DF_16,df)     # append file
  
}


## replace unknown chars in candidate names

DF_16$Candidate <- gsub('ó', '�', DF_16$Candidate)

DF_16$Candidate <- gsub('á', '�', DF_16$Candidate)  
DF_16$Candidate <- gsub('��', '�', DF_16$Candidate) 
DF_16$Candidate <- gsub('�"', '�', DF_16$Candidate)
DF_16$Candidate <- gsub('é', '�', DF_16$Candidate)
DF_16$Candidate <- gsub('�"', '�', DF_16$Candidate)
DF_16$Candidate <- gsub('�-', '�', DF_16$Candidate)
DF_16$Candidate <- gsub('�s', '�', DF_16$Candidate)

##DF_16$Candidate <- gsub('�???', '�', DF_16$Candidate)
DF_16$Candidate <- gsub('�"', '�', DF_16$Candidate)
##DF_16$Candidate <- gsub('�???', '�', DF_16$Candidate)
DF_16$Candidate <- gsub('�', '�', DF_16$Candidate)
DF_16$Candidate <- gsub('�', '�', DF_16$Candidate)
DF_16$Candidate <- gsub('O�???T', '�', DF_16$Candidate)




# The below code allows us to clean each count column down to the transfer votes only
# repeat for counts 2 -15
# then can be additive to get the total votes

DF_16$Count.2 <- ifelse(nchar(DF_16$Count.2)==0, "(0)", DF_16$Count.2)  ## If the column is blank, insert (0)

DF_16$Count.2 <- str_extract_all(DF_16$Count.2, "\\([^()]+\\)") #extract whats in the brackets



DF_16$Count.2 <- gsub( ")", "", DF_16$Count.2) #gets rid of ")" char

DF_16$Count.2 <- gsub( "\\(", "", DF_16$Count.2) #gets rid of "(" char
DF_16$Count.2 <- str_replace(DF_16$Count.2, "character(0)", "0") ##Replace character(0), not working currently


## 3 

DF_16$Count.3 <- ifelse(nchar(DF_16$Count.3)==0, "(0)", DF_16$Count.3)  ## If the column is blank, insert (0)

DF_16$Count.3 <- str_extract_all(DF_16$Count.3, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.3 <- gsub( ")", "", DF_16$Count.3) #gets rid of ")" char

DF_16$Count.3 <- gsub( "\\(", "", DF_16$Count.3) #gets rid of "(" char
DF_16$Count.3 <- str_replace(DF_16$Count.3, "character(0)", "0") ##Replace character(0), not working currently


## 4

DF_16$Count.4 <- ifelse(nchar(DF_16$Count.4)==0, "(0)", DF_16$Count.4)  ## If the column is blank, insert (0)

DF_16$Count.4 <- str_extract_all(DF_16$Count.4, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.4 <- gsub( ")", "", DF_16$Count.4) #gets rid of ")" char

DF_16$Count.4 <- gsub( "\\(", "", DF_16$Count.4) #gets rid of "(" char
DF_16$Count.4 <- str_replace(DF_16$Count.4, "character(0)", "0") ##Replace character(0), not working currently

## 5 

DF_16$Count.5 <- ifelse(nchar(DF_16$Count.5)==0, "(0)", DF_16$Count.5)  ## If the column is blank, insert (0)

DF_16$Count.5 <- str_extract_all(DF_16$Count.5, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.5 <- gsub( ")", "", DF_16$Count.5) #gets rid of ")" char

DF_16$Count.5 <- gsub( "\\(", "", DF_16$Count.5) #gets rid of "(" char
DF_16$Count.5 <- str_replace(DF_16$Count.5, "character(0)", "0") ##Replace character(0), not working currently


# 6

DF_16$Count.6 <- ifelse(nchar(DF_16$Count.6)==0, "(0)", DF_16$Count.6)  ## If the column is blank, insert (0)

DF_16$Count.6 <- str_extract_all(DF_16$Count.6, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.6 <- gsub( ")", "", DF_16$Count.6) #gets rid of ")" char

DF_16$Count.6 <- gsub( "\\(", "", DF_16$Count.6) #gets rid of "(" char
DF_16$Count.6 <- str_replace(DF_16$Count.6, "character(0)", "0") ##Replace character(0), not working currently


## 7

DF_16$Count.7 <- ifelse(nchar(DF_16$Count.7)==0, "(0)", DF_16$Count.7)  ## If the column is blank, insert (0)

DF_16$Count.7 <- str_extract_all(DF_16$Count.7, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.7 <- gsub( ")", "", DF_16$Count.7) #gets rid of ")" char

DF_16$Count.7 <- gsub( "\\(", "", DF_16$Count.7) #gets rid of "(" char
DF_16$Count.7 <- str_replace(DF_16$Count.7, "character(0)", "0") ##Replace character(0), not working currently


# 8 

DF_16$Count.8 <- ifelse(nchar(DF_16$Count.8)==0, "(0)", DF_16$Count.8)  ## If the column is blank, insert (0)

DF_16$Count.8 <- str_extract_all(DF_16$Count.8, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.8 <- gsub( ")", "", DF_16$Count.8) #gets rid of ")" char

DF_16$Count.8 <- gsub( "\\(", "", DF_16$Count.8) #gets rid of "(" char
DF_16$Count.8 <- str_replace(DF_16$Count.8, "character(0)", "0") ##Replace character(0), not working currently


## 9
DF_16$Count.9 <- ifelse(nchar(DF_16$Count.9)==0, "(0)", DF_16$Count.9)  ## If the column is blank, insert (0)

DF_16$Count.9 <- str_extract_all(DF_16$Count.9, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.9 <- gsub( ")", "", DF_16$Count.9) #gets rid of ")" char

DF_16$Count.9 <- gsub( "\\(", "", DF_16$Count.9) #gets rid of "(" char
DF_16$Count.9 <- str_replace(DF_16$Count.9, "character(0)", "0") ##Replace character(0), not working currently


## 10
DF_16$Count.10 <- ifelse(nchar(DF_16$Count.10)==0, "(0)", DF_16$Count.10)  ## If the column is blank, insert (0)

DF_16$Count.10 <- str_extract_all(DF_16$Count.10, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.10 <- gsub( ")", "", DF_16$Count.10) #gets rid of ")" char

DF_16$Count.10 <- gsub( "\\(", "", DF_16$Count.10) #gets rid of "(" char
DF_16$Count.10 <- str_replace(DF_16$Count.10, "character(0)", "0") ##Replace character(0), not working currently


##11
DF_16$Count.11 <- ifelse(nchar(DF_16$Count.11)==0, "(0)", DF_16$Count.11)  ## If the column is blank, insert (0)

DF_16$Count.11 <- str_extract_all(DF_16$Count.11, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.11 <- gsub( ")", "", DF_16$Count.11) #gets rid of ")" char

DF_16$Count.11 <- gsub( "\\(", "", DF_16$Count.11) #gets rid of "(" char
DF_16$Count.11 <- str_replace(DF_16$Count.11, "character(0)", "0") ##Replace character(0), not working currently


#12 
DF_16$Count.12 <- ifelse(nchar(DF_16$Count.12)==0, "(0)", DF_16$Count.12)  ## If the column is blank, insert (0)

DF_16$Count.12 <- str_extract_all(DF_16$Count.12, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.12 <- gsub( ")", "", DF_16$Count.12) #gets rid of ")" char

DF_16$Count.12 <- gsub( "\\(", "", DF_16$Count.12) #gets rid of "(" char

DF_16$Count.12 <- str_replace(DF_16$Count.12, "character(0)", "0") ##Replace character(0), not working currently

## 13
DF_16$Count.13 <- ifelse(nchar(DF_16$Count.13)==0, "(0)", DF_16$Count.13)  ## If the column is blank, insert (0)

DF_16$Count.13 <- str_extract_all(DF_16$Count.13, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.13 <- gsub( ")", "", DF_16$Count.13) #gets rid of ")" char

DF_16$Count.13 <- gsub( "\\(", "", DF_16$Count.13) #gets rid of "(" char
DF_16$Count.13 <- str_replace(DF_16$Count.13, "character(0)", "0") ##Replace character(0), not working currently


## 14
DF_16$Count.14 <- ifelse(nchar(DF_16$Count.14)==0, "(0)", DF_16$Count.14)  ## If the column is blank, insert (0)

DF_16$Count.14 <- str_extract_all(DF_16$Count.14, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.14 <- gsub( ")", "", DF_16$Count.14) #gets rid of ")" char

DF_16$Count.14 <- gsub( "\\(", "", DF_16$Count.14) #gets rid of "(" char
DF_16$Count.14 <- str_replace(DF_16$Count.14, "character(0)", "0") ##Replace character(0), not working currently


#15
DF_16$Count.15 <- ifelse(nchar(DF_16$Count.15)==0, "(0)", DF_16$Count.15)  ## If the column is blank, insert (0)

DF_16$Count.15 <- str_extract_all(DF_16$Count.15, "\\([^()]+\\)") #extract whats in the brackets

DF_16$Count.15 <- gsub( ")", "", DF_16$Count.15) #gets rid of ")" char

DF_16$Count.15 <- gsub( "\\(", "", DF_16$Count.15) #gets rid of "(" char

DF_16$Count.15 <- str_replace(DF_16$Count.15, "character(0)", "0") ##Replace character(0), not working currently

### DATA CLEANING AND TRANSFORMATIONS ###

# get the constituency from the scraping url


download.file("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/const_scrape_url_mapping2016.csv", destfile = "const_scrape_url_mapping2016.csv", mode="wb")

const_mapping_2016 <- read.csv("const_scrape_url_mapping2016.csv")

DF_16 <- left_join(DF_16, const_mapping_2016)


#replace NA with 0 in seat column

DF_16$Seat[is.na(DF_16$Seat)] <- 0
DF_16$Count.1[is.na(DF_16$Count.1)] <- 0


# Get party affiliation from candidate name
# This uses regex within the str_extract_all function to take everything within "(**)" out

DF_16$Party <- str_extract_all(DF_16$Candidate, "\\([^()]+\\)")
DF_16$Count.15 <- str_replace(DF_16$Count.15, "character(0)", "0") ##Replace character(0), not working currently

# Get total votes in first round for each constituency

DF_16_const_summ <- DF_16 %>% 
  group_by(Constituency) %>%
  summarise(n=n(), total_const_vote = sum(Count.1), seats = max(Seat))

DF_16_const_summ$Quota = ceiling(DF_16_const_summ$total_const_vote / (DF_16_const_summ$seats+1)) 

# Merge in constituency info

DF_16 <- left_join(DF_16, DF_16_const_summ, by = c("Constituency"))

is.na(DF_16$Quota)

# get total transfers

DF_16$Count.2<-as.numeric(DF_16$Count.2)
DF_16$Count.3<-as.numeric(DF_16$Count.3)
DF_16$Count.4<-as.numeric(DF_16$Count.4)
DF_16$Count.5<-as.numeric(DF_16$Count.5)
DF_16$Count.6<-as.numeric(DF_16$Count.6)
DF_16$Count.7<-as.numeric(DF_16$Count.7)
DF_16$Count.8<-as.numeric(DF_16$Count.8)
DF_16$Count.9<-as.numeric(DF_16$Count.9)
DF_16$Count.10<-as.numeric(DF_16$Count.10)
DF_16$Count.11<-as.numeric(DF_16$Count.11)
DF_16$Count.12<-as.numeric(DF_16$Count.12)
DF_16$Count.13<-as.numeric(DF_16$Count.13)
DF_16$Count.14<-as.numeric(DF_16$Count.14)
DF_16$Count.15<-as.numeric(DF_16$Count.15)

DF_16$Total_Transfers = (DF_16$Count.2+DF_16$Count.3+DF_16$Count.4+DF_16$Count.5+DF_16$Count.6+DF_16$Count.7+DF_16$Count.8+DF_16$Count.9+DF_16$Count.10+DF_16$Count.11+DF_16$Count.12+DF_16$Count.13+DF_16$Count.14+DF_16$Count.15)

# Get votes as %of Quota

DF_16$FP_Quota_pct <- DF_16$Count.1 / DF_16$Quota

DF_16$Trans_Quota_pct <- DF_16$Total_Transfers / DF_16$Quota

# Elected flag

DF_16 <- DF_16 %>%
  mutate(Elected = case_when(
    Seat > 0 ~ 1,
    Seat < 1 ~ 0
  ))

DF_16[1] <- NULL
DF_16$Count.x <- NULL

## use the gender package to predict candidate sex


Names <- word(DF_16$Candidate, 1)
DF_16$First_Name <- word(DF_16$Candidate, 1)

Candidate_Gender_Kantrowitz = gender(Names, method = "kantrowitz")
Candidate_Gender_genderize = gender(Names, method = "genderize") # API limited - be careful!

Candidate_Gender_Kantrowitz
Candidate_Gender_genderize # this one covers all names

Candidate_Gender_genderize_close <- Candidate_Gender_genderize %>%
  filter(proportion_female < 0.7, proportion_female > 0.3)

Candidate_Detail_Gender_Close <- left_join(Candidate_Gender_genderize_close, DF_16, by = c("name" = "First_Name"))

Candidate_Gender_genderize <- Candidate_Gender_genderize %>%
  mutate(gender = case_when(
    name == 'Dara' ~ 'male',
    name == 'Dessie' ~ 'male',
    name == 'Joan' ~ 'female',
    name == 'Emer' ~ 'female',
    name == 'T.P.' ~ 'male',
    name == 'Se�n' ~ 'male',
    name == 'P�draig' ~ 'male',
    name == 'Aindrias' ~ 'male',
    name == 'Ciar�n' ~ 'male',
    name == 'Miche�l' ~ 'male',
    name == 'Aodh�n' ~ 'male',
    name == 'Oghenetano' ~ 'male',
    name == 'Deagl�n' ~ 'male',
    name == '�amon' ~ 'male',
    name == 'n�all' ~ 'male',
    name == 'Ruair�' ~ 'male',
    name == 'Daith�' ~ 'male',
    name == 'Seighin' ~ 'male',
    TRUE ~ gender) )

Candidate_Gender_genderize_old <- Candidate_Gender_genderize 

Candidate_Gender_genderize_distinct <- Candidate_Gender_genderize %>%
  distinct(.keep_all = TRUE)

DF_16$gender <- NULL
DF_16$proportion_male <- NULL
DF_16$proportion_female <- NULL

DF_16 <- left_join(DF_16, Candidate_Gender_genderize_distinct, by = c("First_Name"="name"))

# tidy up names not covered in genderize
# try kantrowitz

DF_16_NA <- DF_16[is.na(DF_16$gender),]

DF_16 <- DF_16 %>%
  mutate(gender = case_when(
    !is.na(gender) ~ gender,
    TRUE ~ 'female'
  ))

DF_16 <- DF_16 %>%
  mutate(gender = case_when(
    First_Name == 'T.P.' ~ 'male',
    First_Name == 'Se�n' ~ 'male',
    First_Name == 'P�draig' ~ 'male',
    First_Name == 'Aindrias' ~ 'male',
    First_Name == 'Ciar�n' ~ 'male',
    First_Name == 'Miche�l' ~ 'male',
    First_Name == 'Aodh�n' ~ 'male',
    First_Name == 'Oghenetano' ~ 'male',
    First_Name == 'Deagl�n' ~ 'male',
    First_Name == '�amon' ~ 'male',
    First_Name == 'N�all' ~ 'male',
    First_Name == 'Ruair�' ~ 'male',
    First_Name == 'Daith�' ~ 'male',
    First_Name == 'Seighin' ~ 'male',
    is.na(gender) ~ 'female',
    TRUE ~ gender  )) 

# check NAs again

DF_16_NA <- DF_16[is.na(DF_16$gender),]


#Clean data in DF_16

DF_16 <- DF_16 %>%
  mutate(Candidate = case_when(
    Candidate == 'Eoin �Broin' ~ 'Eoin �Broin',
    Candidate == 'Aodh�n �R�ord�in'~ 'Aodh�n �R�ord�in',
    Candidate == 'Aengus �Snodaigh'~ 'Aengus �Snodaigh',
    TRUE ~ Candidate
  ))


# Can we look up if a candidate was elected or not?

# clean up candidate column 

DF$Candidate <- str_replace(DF$Candidate, " \\s*\\([^\\)]+\\)", "")

DF_16$Candidate <-  str_replace(DF_16$Candidate, " \\s*\\([^\\)]+\\)", "")



# First do 2020

DF_16_lookup <- DF_16 %>%
  select(Candidate, Elected, Seat)

colnames(DF_16_lookup) <- c("Candidate",  "Elected_Prior_Election","Seat_Prior_Election")

DF <- left_join(DF, DF_16_lookup, by = "Candidate")


DF <- DF %>%
  mutate(Elected_Prior_Election = case_when(
    Candidate == 'Malcolm Byrne (FF)' ~ 1,
    Candidate == 'Mark Ward (SF)'~ 1,
    Candidate == "Joe O'Brien (GP)"~ 1,
    Candidate == "P�draig O'Sullivan (FF)" ~ 1,
    TRUE ~ 0
  ))



# Do 2016, using a summary of incumbents from 2011

DF_16 <- as.data.frame(DF_16)

DF_16$Candidate <- str_replace(DF_16$Candidate, " \\s*\\([^\\)]+\\)", "")

download.file("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/2011_Incumbency.csv", destfile = "2011_Incumbency.csv", mode="wb")

DF_11_lookup <-  read.csv("2011_Incumbency.csv")

DF_16 <- left_join(DF_16, DF_11_lookup, by = "Candidate")


DF <- DF %>%
  mutate(Elected_Prior_Election = case_when(
    Candidate == 'Malcolm Byrne (FF)' ~ 1,
    Candidate == 'Mark Ward (SF)'~ 1,
    Candidate == "Joe O'Brien (GP)"~ 1,
    Candidate == "P�draig O'Sullivan (FF)" ~ 1,
    TRUE ~ 0
  ))


## now gather and incorporate other datasets 

# polling data

download.file("https://github.com/GarySwan1994/Dissertation_Files/raw/main/data_polls.xlsx", destfile = "data_polls.xlsx", mode="wb")
Polls <-  readxl::read_xlsx("data_polls.xlsx")
library(dplyr)
library(tidyr)
library(lubridate)

## remove unneeded polling data

Polls <- Polls[,c(1, 7:11, 15:17, 19)]

# create party as one feature, rather than splittign the polling percent by it

Polls_unpivot <- Polls %>%
  gather(key = "Party", value = "Poll.Percent", 2:10)


# repalce NAs with 0 

Polls_unpivot$Poll.Percent[is.na(Polls_unpivot$Poll.Percent)] <- 0

# convert date column to date type 

Polls_unpivot$date <- ymd(Polls_unpivot$date)

Election_Date_2016 = ymd("2016/02/26")

Election_Date_2020 = ymd("2020/02/08")

Election_Date_filter = ymd("2015/03/01")


# denote which election period each poll is in

Polls_unpivot <- Polls_unpivot %>%
  filter(date > Election_Date_filter)%>%
  mutate(cycle = case_when(
    date < Election_Date_2016  ~ '2011-2016', 
    date < Election_Date_2020  ~ '2016-2020'
  ))


# create a feature to denote in the poll was in the last 90 days

Polls_unpivot <- Polls_unpivot %>%
  mutate(Latest_Polls = case_when(
    cycle == '2011-2016' & date < Election_Date_2016 & date > (Election_Date_2016 - 91) ~ 1, 
    cycle == '2016-2020' & date < Election_Date_2020 & date > (Election_Date_2020 - 91) ~ 1,
    TRUE ~ 0
  ))



# create a feature to denote in the poll was in the last 90 days 1 month before the election

Polls_unpivot <- Polls_unpivot %>%
  mutate(one_Month_Polls = case_when(
    cycle == '2011-2016' & date < (Election_Date_2016 -30) & date > (Election_Date_2016 - 121) ~ 1, 
    cycle == '2016-2020' & date < (Election_Date_2020 -30) & date > (Election_Date_2020 - 121) ~ 1,
    TRUE ~ 0
  ))

# create a feature to denote in the poll  was in the last 90 days 3 months before the election

Polls_unpivot <- Polls_unpivot %>%
  mutate(three_Month_Polls = case_when(
    cycle == '2011-2016' & date < (Election_Date_2016 -90) & date > (Election_Date_2016 - 181) ~ 1, 
    cycle == '2016-2020' & date < (Election_Date_2020 -90) & date > (Election_Date_2020 - 181) ~ 1,
    TRUE ~ 0
  ))

# create new poll averages based on teh time period the poll was conducted during 



Polls_unpivot_recent <- Polls_unpivot %>%
  filter(Latest_Polls == 1) %>%
  mutate(Latest_Poll_Pct = case_when(
    Latest_Polls == 1 ~ Poll.Percent,
    TRUE ~ 0 
  )) 

Polls_unpivot_1mo <- Polls_unpivot %>%
  filter(one_Month_Polls == 1) %>%
  mutate(one_Month_Poll_Pct = case_when(
    one_Month_Polls == 1 ~ Poll.Percent,
    TRUE ~ 0 
  )) 
  
Polls_unpivot_3mo <- Polls_unpivot %>%
  filter(three_Month_Polls == 1) %>%
  mutate(three_Month_Poll_Pct = case_when(
    three_Month_Polls == 1 ~ Poll.Percent,
    TRUE ~ 0 
  )) 

  
# summarise the polling data


Poll_Summary_recent <- Polls_unpivot_recent %>%
  group_by(cycle, Party) %>%
  summarise(Poll_Avg_Recent = mean(Latest_Poll_Pct))

Poll_Summary_1mo <- Polls_unpivot_1mo %>%
  group_by(cycle, Party) %>%
  summarise( Poll_Avg_1mo = mean(one_Month_Poll_Pct))

Poll_Summary_3mo <- Polls_unpivot_3mo %>%
  group_by(cycle, Party) %>%
  summarise(Poll_Avg_3mo = mean(three_Month_Poll_Pct))

# merge all together

Poll_Summary  = left_join(Poll_Summary_recent, Poll_Summary_1mo)
Poll_Summary  = left_join(Poll_Summary, Poll_Summary_3mo)




# clean party column in electoral data to match political data

DF$Party <- gsub("(", "", DF$Party, fixed = TRUE) 
DF$Party <- gsub(")", "", DF$Party, fixed = TRUE) 


DF_16$Party <- gsub("(", "", DF_16$Party, fixed = TRUE)

DF_16$Party <- gsub(")", "", DF_16$Party, fixed = TRUE)


## add in census data


download.file("https://www.cso.ie/en/media/csoie/census/census2016/census2016boundaryfiles/SAPS2016_DC2017.csv", destfile = "SAPS2016_DC2017.csv", mode="wb")

Census = read.csv("SAPS2016_DC2017.csv")

Census$GEOGDESC <- gsub("-", "-", Census$GEOGDESC )

Census_const <- Census %>%
  group_by(GEOGDESC) %>%
  summarise(n=n())


## above merge shows the consituency data does merge lceanly

# now, create new features on the Census DF

Census$GEOGDESC <- gsub("-", "-", Census$GEOGDESC )

# get population splits

# Under 18s (shortcut to over 18s)

Census$Under_18 <- Census$T1_1AGE0T+Census$T1_1AGE1T+Census$T1_1AGE2T+Census$T1_1AGE3T+Census$T1_1AGE4T+Census$T1_1AGE5T+Census$T1_1AGE6T+Census$T1_1AGE7T+Census$T1_1AGE8T+Census$T1_1AGE9T+Census$T1_1AGE10T+Census$T1_1AGE11T+Census$T1_1AGE12T+Census$T1_1AGE13T+Census$T1_1AGE14T+Census$T1_1AGE15T+Census$T1_1AGE16T+Census$T1_1AGE17T


# 65+ 

Census$Over_65 <- Census$T1_1AGE65_69T+Census$T1_1AGE70_74T+Census$T1_1AGE75_79T+Census$T1_1AGE80_84T+Census$T1_1AGEGE_85T


# 35+ 

Census$Over_35 <- Census$Over_65 + Census$T1_1AGE35_39T+Census$T1_1AGE40_44T+Census$T1_1AGE45_49T+Census$T1_1AGE50_54T+Census$T1_1AGE55_59T+Census$T1_1AGE60_64T

# Do proportions as% of pop


Census$Over_65_pct <- round(Census$Over_65 / Census$T1_1AGETT,3)
Census$Over_35_pct <- round(Census$Over_35 / Census$T1_1AGETT,3)
Census$Over_18_pct <- 1 - round((Census$Under_18 / Census$T1_1AGETT),3)

Census$Female_pct <- (Census$T1_2TF / Census$T1_2T)

Census$Ireland_birth_pct <- (Census$T2_1IEBP / Census$T2_1TN)
Census$Not_Stated_birth_pct <- (Census$T2_1NSN / Census$T2_1TN)

Census$Catholic_pct <- (Census$T2_4CA / Census$T2_4T)

Census$Irish_over3_pct <- (Census$T3_1YES / Census$T3_1T)

Census$Irish_Daily_Outside_Educ_pct <- (Census$T3_2DOEST / Census$T3_1T)

Census$Irish_Daily_And_In_Educ_pct <- (Census$T3_2DIDOT / Census$T3_1T)


Census$Two_person_household_hou_pct <- (Census$T4_1_2PF / Census$T4_1_TF)

Census$Two_person_household_ppl_pct <- Census$T4_1_2PP/Census$T4_1_TP


Census$Apartment_household_hou_pct  <- Census$T6_1_FA_H/Census$T6_1_TH

Census$Apartment_household_pp_pct  <- Census$T6_1_FA_P/Census$T6_1_TP

Census$Rental_private_hou_pct  <- Census$T6_3_RPLH/Census$T6_3_TH

Census$Rental_private_household_pp_pct  <-  Census$T6_3_RPLP/Census$T6_3_TP


Census$Age_15plus_unemployed  <-  Census$T8_1_ULGUPJT/Census$T8_1_TT


Census$Degree_or_higher_pct  <- (Census$T10_4_HDPQT + Census$T10_4_PDT+ Census$T10_4_DT)/ Census$T10_4_TT


Census$Ord_Degree_or_higher_pct  <- (Census$T10_4_ODNDT +Census$T10_4_HDPQT + Census$T10_4_PDT+ Census$T10_4_DT)/ Census$T10_4_TT

Census$UK_birth_pct <- (Census$T2_1UKBP / Census$T2_1TN)
Census$Wh_irish <- (Census$T2_2WI / Census$T2_2T)
Census$Wh_irish_trv <- (Census$T2_2WIT / Census$T2_2T)
Census$married_pct <- (Census$T1_2MART / Census$T1_2T)
Census$divorced_pct <- (Census$T1_2DIVT / Census$T1_2T)
Census$socio_A_B_pct <- (   (Census$T9_2_HA  + Census$T9_2_HB )/ Census$T9_2_PT)

## Census, usign 2013 boundaries


download.file("https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/SAPS2016_DC2013.csv", destfile = "SAPS2016_DC2013.csv", mode="wb")

Census_13 = read.csv("SAPS2016_DC2013.csv")

Census_13$GEOGDESC <- gsub("-", "-", Census_13$GEOGDESC )

Census_13_const <- Census_13 %>%
  group_by(GEOGDESC) %>%
  summarise(n=n())


## above merge shows the consituency data does merge lceanly

# now, create new features on the Census_13 DF

Census_13$GEOGDESC <- gsub("-", "-", Census_13$GEOGDESC )

# get population splits

# Under 18s (shortcut to over 18s)

Census_13$Under_18 <- Census_13$T1_1AGE0T+Census_13$T1_1AGE1T+Census_13$T1_1AGE2T+Census_13$T1_1AGE3T+Census_13$T1_1AGE4T+Census_13$T1_1AGE5T+Census_13$T1_1AGE6T+Census_13$T1_1AGE7T+Census_13$T1_1AGE8T+Census_13$T1_1AGE9T+Census_13$T1_1AGE10T+Census_13$T1_1AGE11T+Census_13$T1_1AGE12T+Census_13$T1_1AGE13T+Census_13$T1_1AGE14T+Census$T1_1AGE15T+Census$T1_1AGE16T+Census$T1_1AGE17T


# 65+ 

Census_13$Over_65 <- Census_13$T1_1AGE65_69T+Census_13$T1_1AGE70_74T+Census_13$T1_1AGE75_79T+Census_13$T1_1AGE80_84T+Census_13$T1_1AGEGE_85T


# 35+ 

Census_13$Over_35 <- Census_13$Over_65 + Census_13$T1_1AGE35_39T+Census_13$T1_1AGE40_44T+Census_13$T1_1AGE45_49T+Census_13$T1_1AGE50_54T+Census_13$T1_1AGE55_59T+Census_13$T1_1AGE60_64T

# Do proportions as% of pop


Census_13$Over_65_pct <- round(Census_13$Over_65 / Census_13$T1_1AGETT,3)
Census_13$Over_35_pct <- round(Census_13$Over_35 / Census_13$T1_1AGETT,3)
Census_13$Over_18_pct <- 1 - round((Census_13$Under_18 / Census_13$T1_1AGETT),3)

Census_13$Female_pct <- (Census_13$T1_2TF / Census_13$T1_2T)

Census_13$Ireland_birth_pct <- (Census_13$T2_1IEBP / Census_13$T2_1TN)
Census_13$Not_Stated_birth_pct <- (Census_13$T2_1NSN / Census_13$T2_1TN)

Census_13$Catholic_pct <- (Census_13$T2_4CA / Census_13$T2_4T)

Census_13$Irish_over3_pct <- (Census_13$T3_1YES / Census_13$T3_1T)

Census_13$Irish_Daily_Outside_Educ_pct <- (Census_13$T3_2DOEST / Census_13$T3_1T)

Census_13$Irish_Daily_And_In_Educ_pct <- (Census_13$T3_2DIDOT / Census_13$T3_1T)


Census_13$Two_person_household_hou_pct <- (Census_13$T4_1_2PF / Census_13$T4_1_TF)

Census_13$Two_person_household_ppl_pct <- Census_13$T4_1_2PP/Census_13$T4_1_TP


Census_13$Apartment_household_hou_pct  <- Census_13$T6_1_FA_H/Census_13$T6_1_TH

Census_13$Apartment_household_pp_pct  <- Census_13$T6_1_FA_P/Census_13$T6_1_TP

Census_13$Rental_private_hou_pct  <- Census_13$T6_3_RPLH/Census_13$T6_3_TH

Census_13$Rental_private_household_pp_pct  <-  Census_13$T6_3_RPLP/Census_13$T6_3_TP


Census_13$Age_15plus_unemployed  <-  Census_13$T8_1_ULGUPJT/Census_13$T8_1_TT


Census_13$Degree_or_higher_pct  <- (Census_13$T10_4_HDPQT + Census_13$T10_4_PDT+ Census_13$T10_4_DT)/ Census_13$T10_4_TT


Census_13$Ord_Degree_or_higher_pct  <- (Census_13$T10_4_ODNDT +Census_13$T10_4_HDPQT + Census_13$T10_4_PDT+ Census_13$T10_4_DT)/ Census_13$T10_4_TT

Census_13$UK_birth_pct <- (Census_13$T2_1UKBP / Census_13$T2_1TN)
Census_13$Wh_irish <- (Census_13$T2_2WI / Census_13$T2_2T)
Census_13$Wh_irish_trv <- (Census_13$T2_2WIT / Census_13$T2_2T)
Census_13$married_pct <- (Census_13$T1_2MART / Census_13$T1_2T)
Census_13$divorced_pct <- (Census_13$T1_2DIVT / Census_13$T1_2T)
Census_13$socio_A_B_pct <- (   (Census_13$T9_2_HA  + Census_13$T9_2_HB )/ Census_13$T9_2_PT)

# output the files for merging later

write.csv(DF, "2020 Election Data Pre-Merge.csv")
write.csv(DF_16, "2016 Election Data Pre-Merge.csv")
write.csv(Poll_Summary, "Polling Data Pre-Merge.csv")
write.csv(Census, "2017 Boundary Census Data Pre-Merge.csv")
write.csv(Census_13, "2013 Boundary Census Data Pre-Merge.csv")


'''
DF <- DF %>%
  mutate(Constituency = case_when(
    Constituency == 'Donegal<' ~ 'Donegal',
    TRUE ~ Constituency  ))


DF_Summ <- DF %>%
  group_by(Constituency) %>%
  summarise(n=n())


merge_test2 <- left_join(Census_const, DF_Summ, by = c("GEOGDESC"="Constituency"))

merge_test_DF <- left_join(DF_Summ, Census_const, by = c("Constituency"="GEOGDESC"))
'''

## clean up 2020 results table a bit - 2022 03 06
# add some new party vote share features!


DF <- rename(DF, Incumbent = Elected.y )

DF <- DF %>%
  mutate(Incumbent = case_when(
    Seat.y > 0 ~ 1,
    TRUE ~ 0
  ))

DF <- rename(DF, FP_Votes_Party_2016 = FP_Votes)

DF <- rename(DF, Total_Votes_Party_2016 = total_votes)
DF <- rename(DF, pct_share_Party_2016 = pct_share)
DF <- rename(DF, Cand_FP_Share_2020 = Share)


# make bin ranges for the vote share data

# make it numeric first 
DF$Cand_FP_Share_2020 <- gsub("%","",(DF$Cand_FP_Share_2020))

DF$Cand_FP_Share_2020 <- as.numeric(DF$Cand_FP_Share_2020)

DF$Cand_FP_Share_2020 <- DF$Cand_FP_Share_2020/100

# now do binning

DF <- DF %>%
  mutate(Cand_FP_Share_2020_Bin = 
           cut(Cand_FP_Share_2020, seq(0, 1, .02)
           ))

DFx <- DF %>%
  mutate(Cand_FP_Share_2020_Bin = 
           cut(Cand_FP_Share_2020, seq(0, 1, .02)
           ))

# finds NAS
DF_na_FP_Quota <- DF[is.na(DF$FP_Quota_pct_bins)]

DF <- DF %>%
  mutate(Cand_FP_Share_2020_Bin = 
           cut(Cand_FP_Share_2020, seq(0, 1, .02)
           ))



DF <- DF %>%
  mutate(FP_Quota_pct_bins = 
           cut(FP_Quota_pct, seq(0, 1, .05)
           ) )

DF$FP_Quota_pct_bins <- as.character(DF$FP_Quota_pct_bins)


DF <- DF %>%
  mutate(FP_Quota_pct_bins = 
           case_when(
             FP_Quota_pct > 1 ~ '[1,2]',
             FP_Quota_pct < 1.00001  ~ FP_Quota_pct_bins
           ) )

DF$Trans_Quota_pct

## Do some data cleansing

DF$X.7 <- NULL
DF$X.6 <- NULL
DF$X.5 <- NULL
DF$X.4 <- NULL
DF$X.3 <- NULL
DF$X.2 <- NULL
DF$X.1 <- NULL
DF$X <- NULL
DF$web.scraper.start.url <- NULL
DF$n <- NULL
DF$proportion_female <- NULL
DF$proportion_male <- NULL

DF <- rename(DF, Seat_2016 = Seat.y )

is.na(DF$Seat_2016)

sum(is.na(DF$Seat_2016))

DF <- DF %>%
  mutate(Seat_2016 = case_when(
    is.na(Seat_2016) ~ 0L,
    TRUE ~ Seat_2016
  ))

DF <- rename(DF, Seat_2020 = Seat.x )


# Create a constituency-party table

DF_Party <- DF %>%
  group_by(Constituency, Party) %>%
  summarise(Count.1 = sum(Count.1), Count.2 = sum(Count.2), Count.3 = sum(Count.3), Count.4 = sum(Count.4), Count.5 = sum(Count.5), Count.6 = sum(Count.6), Count.7 = sum(Count.7), Count.8 = sum(Count.8), Count.9 = sum(Count.9), Count.10 = sum(Count.10), Count.11 = sum(Count.11), Count.12 = sum(Count.12), Count.13 = sum(Count.13), Count.14 = sum(Count.14), Count.15 = sum(Count.15), Total_Transfers = sum(Total_Transfers), Quota = mean(Quota), Elected.x = sum(Elected.x), FP_Votes_Party_2016 = mean(FP_Votes_Party_2016), Total_Votes_Party_2016 = mean(Total_Votes_Party_2016), Average_All = mean(Average_All), Average_90 = mean(Average_90), Average_Year = mean(Average_Year), Delta_90 = mean(Delta_90), Delta_Year = mean(Delta_Year), Delta_All = mean(Delta_All))

sum(DF_Party$Elected.x)



# Export Data 2022 03 12

## ~ ~ ~ update to an online link

write.csv(DF_Party, "all_const_party 2022 03 12.csv", row.names = FALSE)

write.csv(DF, "all_const_2022 03 12.csv", row.names = FALSE)


# Export const data on 2022 03 09 


write.csv(DF, "all_const_2022 03 09.csv", row.names = FALSE)


# Export census data 04 03 2022

getwd()

write.csv(Census, "Census_2022 03 04.csv")

# Export census data 27 02 2022

getwd()

write.csv(Census, "Census_2022 02 27.csv")

# Export everything from today 26 02 2022

## ~ ~ ~ update to an online link

setwd("C:/Users/35385/Documents/College/Dissertation/Datasets")


# Poll data

write.csv(Polls_unpivot, "Poll Unpivoted 2022 02 26.csv")

# Update const data

write.csv(DF, "all_const_2022 02 26.csv")

# Export everything from today 24 02 2022

setwd("C:/Users/35385/Documents/College/Dissertation/Datasets")


# Poll data

write.csv(Polls_unpivot, "Poll Unpivoted 2022 02 24.csv")

# Update const data

write.csv(DF, "all_const_2022 02 24.csv")


# re import

setwd("C:/Users/35385/Documents/College/Dissertation/Datasets")

DF <- read.csv("all_const_2022 03 09.csv")

Polls_unpivot <- read.csv("Poll Unpivoted 2022 02 24.csv")

Census <- read.csv("Census_2022 03 04.csv")

# 2016


setwd("C:/Users/35385/Documents/College/Dissertation/Datasets/Data Scrape/2016 const")

DF_2016 <- read.csv("2016_all_const_2022 02 20.csv")

# import dataset w incumbency

setwd("C:/Users/35385/Documents/College/Dissertation/Datasets/Data Scrape/2016 const")

DF_Joined_Init <- read.csv('left join 2020 to 2016 incumbency.csv')

DF_Joined_Init  <- DF_Joined_Init  %>%
  mutate()

write.csv(DF_probability, 'DF_probability.csv')


#Export const file 
setwd("~/College/Dissertation/Initial research - Irish politics/Data Scrape")

write.csv(DF_const_summ, "const_summ.csv")



#writing the appended file


write.csv(DF, "all_const_2022 02 13.csv")


# improt file back in 

## ~ ~ ~ update to an online link

setwd("C:/Users/35385/Documents/College/Dissertation/Datasets/Data Scrape")

##DF <- read.csv("all_const.csv")

##DF <- readxl::read_xlsx("all_const.xlsx")



# Load constituency info 

#setwd("~/College/Dissertation/Initial research - Irish politics/Data Scrape")

#const_info <- read.csv("const_url_match.csv")  - use this file for loading MD for constituencys!

DF <- merge(DF, const_info, by = "web.scraper.start.url")



### do 2016 data

setwd("C:/Users/35385/Documents/College/Dissertation/Datasets/Data Scrape/2016 const")
library(gender)
library(stringr)

DF_16 <- read.csv("2016_all_const_2022 04 09.csv")


Names <- word(DF_16$Candidate, 1)
DF_16$First_Name <- word(DF_16$Candidate, 1)

Candidate_Gender_Kantrowitz = gender(Names, method = "kantrowitz")
Candidate_Gender_genderize = gender(Names, method = "genderize") # API limited - be careful!

Candidate_Gender_Kantrowitz
Candidate_Gender_genderize # this one covers all names

Candidate_Gender_genderize_close <- Candidate_Gender_genderize %>%
  filter(proportion_female < 0.7, proportion_female > 0.3)

Candidate_Detail_Gender_Close <- left_join(Candidate_Gender_genderize_close, DF_16, by = c("name" = "First_Name"))

# check or NAs, manually correct these below

Candidate_Gender_genderize_NA <- Candidate_Gender_genderize %>%
  filter(is.na(gender))

Candidate_Gender_genderize <- Candidate_Gender_genderize %>%
  mutate(gender = case_when(
    name == 'Bernie' ~ 'Female',
    name == 'Dara' ~ 'male',
    name == 'Dessie' ~ 'male',
    name == 'Joan' ~ 'female',
    name == 'Emer' ~ 'female',
    name == 'T.P.' ~ 'male',
    name == 'Se�n' ~ 'male',
    name == 'P�draig' ~ 'male',
    name == 'Aindrias' ~ 'male',
    name == 'Ciar�n' ~ 'male',
    name == 'Miche�l' ~ 'male',
    name == 'Aodh�n' ~ 'male',
    name == 'Oghenetano' ~ 'male',
    name == 'Deagl�n' ~ 'male',
    name == '�amon' ~ 'male',
    name == 'n�all' ~ 'male',
    name == 'Ruair�' ~ 'male',
    name == 'Daith�' ~ 'male',
    name == 'Seighin' ~ 'male',
    name == 'Caoimhgh�n' ~ 'female',
    name == '�ine' ~ 'female',
    name == 'M�che�l' ~ 'male',
    name == 'Gleanna' ~ 'female',
    name == '�ilis' ~ 'female',
    name == 'R�is�n' ~ 'female',
    name == 'M�ire' ~ 'female',
    name == 'Br�d' ~ 'female',
    name == 'T.J.' ~ 'male',
    name == 'Mair�ad' ~ 'female',
    name == 'R�ada' ~ 'female',
    name == 'Manch�n' ~ 'male',
    name == 'Gear�id' ~ 'male',
    name == 'Siobh�n' ~ 'female',
    name == '�na' ~ 'female',
    TRUE ~ gender) )

Candidate_Gender_genderize_old <- Candidate_Gender_genderize 

Candidate_Gender_genderize_distinct <- Candidate_Gender_genderize %>%
  distinct(.keep_all = TRUE)

DF$gender <- NULL
DF$proportion_male <- NULL
DF$proportion_female <- NULL


DF_16 <- left_join(DF_16, Candidate_Gender_genderize_distinct, by = c("First_Name" = "name"))

DF_16$proportion_male <- NULL
DF_16$proportion_female <- NULL


write.csv(DF_16, "2016_all_const_2022 04 10.csv")

# tidy up names not covered in genderize
# try kantrowitz

DF_NA <- DF[is.na(DF$gender),]

DF <- DF %>%
  mutate(gender = case_when(
    !is.na(gender) ~ gender,
    TRUE ~ 'female'
  ))

DF <- DF %>%
  mutate(gender = case_when(
    First_Name == 'T.P.' ~ 'male',
    First_Name == 'Se�n' ~ 'male',
    First_Name == 'P�draig' ~ 'male',
    First_Name == 'Aindrias' ~ 'male',
    First_Name == 'Ciar�n' ~ 'male',
    First_Name == 'Miche�l' ~ 'male',
    First_Name == 'Aodh�n' ~ 'male',
    First_Name == 'Oghenetano' ~ 'male',
    First_Name == 'Deagl�n' ~ 'male',
    First_Name == '�amon' ~ 'male',
    First_Name == 'N�all' ~ 'male',
    First_Name == 'Ruair�' ~ 'male',
    First_Name == 'Daith�' ~ 'male',
    First_Name == 'Seighin' ~ 'male',
    is.na(gender) ~ 'female',
    TRUE ~ gender  )) 
