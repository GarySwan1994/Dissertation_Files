# -*- coding: utf-8 -*-
"""
Created on Sat Mar 19 18:01:18 2022

@author: Gary Swan

@Title: .py file with feature selection code
"""

### Dissertation - feature selection

## At party level

# get data

import os 

import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn import preprocessing

from sklearn.model_selection import GridSearchCV


from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix 

os.chdir('C:/Users/35385/Documents/College/Dissertation/Datasets') # go to directory

DF = pd.read_csv('https://raw.githubusercontent.com/GarySwan1994/Dissertation_Files/main/2party_feature_selection%202022%2005%2015.csv', encoding = 'cp1252') # load the CSV

DF.pop('Constituency')

y = DF.pop('FP_Share').values


# Uses SVM, but plug in any of the models below

from sklearn.linear_model import LinearRegression as Reg
from sklearn.svm import SVC as SVC
from sklearn.svm import SVR as SVR
from sklearn.ensemble import RandomForestRegressor as RFR
from sklearn.ensemble import RandomForestClassifier as RFC
from sklearn.tree import DecisionTreeClassifier as DTC
from sklearn.tree import DecisionTreeRegressor as DTR

from sklearn.neighbors import KNeighborsClassifier as kNN
from sklearn.naive_bayes import  GaussianNB as GNB, CategoricalNB as CNB

from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import SelectKBest, chi2, mutual_info_classif
from mlxtend.feature_selection import SequentialFeatureSelector as SFS

## first round feature selection - test the explainable power of diff groups of variables
## that exhibit collinearity

## Housing

DF_housing = DF[['Two_person_household_ppl_pct', 'Apartment_household_pp_pct','Rental_private_household_pp_pct']]

feature_names = DF_housing.columns

X_housing = DF_housing

X_housing.columns = feature_names

min_max_scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))

X_housing = pd.DataFrame(min_max_scaler.fit_transform(X_housing))


#DTR to split the housing features

sfs_forward_1 = SFS(DTR(), 
                  k_features=1, 
                  forward=True, 
                  floating=False,
                  scoring='neg_mean_squared_error',    #accuracy for classification!
                  cv=10, n_jobs = -1)

sfs_forward_1= sfs_forward_1.fit(X_housing, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_forward_features = pd.DataFrame(sfs_forward_1.k_feature_names_)

svm_mask = np.in1d(feature_names, sfs_forward_features)

# try backwards

sfs_back_1 = SFS(DTR(), 
                  k_features=1, 
                  forward=False, 
                  floating=False,
                  scoring='neg_mean_squared_error',    #accuracy for classification!
                  cv=10, n_jobs = -1)

sfs_back_1= sfs_back_1.fit(X_housing, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_back_features = pd.DataFrame(sfs_back_1.k_feature_names_)

## SVR

# SVM Regr

sfs_forward_SVM_1 = SFS(SVR(), 
                  k_features=1, 
                  forward=True, 
                  floating=False,
                  scoring='neg_mean_squared_error',    #accuracy for classification!
                  cv=10, n_jobs = -1)

sfs_forward_SVM_1 = sfs_forward_SVM_1.fit(X_housing, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_SVM_1.k_feature_names_

sfs_forward_SVM_features =  pd.DataFrame(sfs_forward_SVM_1.k_feature_names_)

sfs_back_SVM_1 = SFS(SVR(), 
                  k_features=1, 
                  forward=False, 
                  floating=False,
                  scoring='neg_mean_squared_error',    #accuracy for classification!
                  cv=10, n_jobs = -1)

sfs_back_SVM_1 = sfs_back_SVM_1.fit(X_housing, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_SVM_1.k_feature_names_

sfs_back_SVM_features =  pd.DataFrame(sfs_back_SVM_1.k_feature_names_)


## random forest SFS


sfs_forward_RF_1 = SFS(RFR(), 
                  k_features=1, 
                  forward=True, 
                  floating=False,
                  scoring='neg_mean_squared_error',    #accuracy for classification!
                  cv=10, n_jobs = -1)

sfs_forward_RF_1 = sfs_forward_RF_1.fit(X_housing, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_RF_1.k_feature_names_

sfs_forward_RF_features =  pd.DataFrame(sfs_forward_RF_1.k_feature_names_)

sfs_back_RF_1 = SFS(RFR(), 
                  k_features=1, 
                  forward=False, 
                  floating=False,
                  scoring='neg_mean_squared_error',    #accuracy for classification!
                  cv=10, n_jobs = -1)

sfs_back_RF_1 = sfs_back_RF_1.fit(X_housing, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_RF_1.k_feature_names_

sfs_back_RF_features =  pd.DataFrame(sfs_back_RF_1.k_feature_names_)


# repeat for culture/ethnicity


DF_ethnicity = DF[['Ireland_birth_pct','Catholic_pct','Wh_irish']]

feature_names = DF_ethnicity.columns

DF_ethnicity.columns = feature_names

X_ethnicity = pd.DataFrame(min_max_scaler.fit_transform(DF_ethnicity))

# try forwards

sfs_forward_1= sfs_forward_1.fit(X_ethnicity, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_forward_features = pd.DataFrame(sfs_forward_1.k_feature_names_)

svm_mask = np.in1d(feature_names, sfs_forward_features)

# try backwards

sfs_back_1= sfs_back_1.fit(X_ethnicity, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_back_features = pd.DataFrame(sfs_back_1.k_feature_names_)

# try forwards
sfs_forward_SVM_1 = sfs_forward_SVM_1.fit(X_ethnicity, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_SVM_1.k_feature_names_

sfs_forward_SVM_features =  pd.DataFrame(sfs_forward_SVM_1.k_feature_names_)


# try backwards

sfs_back_SVM_1 = sfs_back_SVM_1.fit(X_ethnicity, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_SVM_1.k_feature_names_

sfs_back_SVM_features =  pd.DataFrame(sfs_back_SVM_1.k_feature_names_)

# try forwards
sfs_forward_RF_1 = sfs_forward_RF_1.fit(X_ethnicity, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_RF_1.k_feature_names_

sfs_forward_RF_features =  pd.DataFrame(sfs_forward_RF_1.k_feature_names_)

# try backwards

sfs_back_RF_1 = sfs_back_RF_1.fit(X_ethnicity, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_RF_1.k_feature_names_

sfs_back_RF_features =  pd.DataFrame(sfs_back_RF_1.k_feature_names_)


### age


DF_age = DF[['Over_65_pct','Over_35_pct']]

feature_names = DF_age.columns

DF_age.columns = feature_names

X_age = pd.DataFrame(min_max_scaler.fit_transform(DF_age))

# try forwards

sfs_forward_1= sfs_forward_1.fit(X_age, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_forward_features = pd.DataFrame(sfs_forward_1.k_feature_names_)

svm_mask = np.in1d(feature_names, sfs_forward_features)

# try backwards

sfs_back_1= sfs_back_1.fit(X_age, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_back_features = pd.DataFrame(sfs_back_1.k_feature_names_)

# try forwards
sfs_forward_SVM_1 = sfs_forward_SVM_1.fit(X_age, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_SVM_1.k_feature_names_

sfs_forward_SVM_features =  pd.DataFrame(sfs_forward_SVM_1.k_feature_names_)


# try backwards

sfs_back_SVM_1 = sfs_back_SVM_1.fit(X_age, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_SVM_1.k_feature_names_

sfs_back_SVM_features =  pd.DataFrame(sfs_back_SVM_1.k_feature_names_)

# try forwards
sfs_forward_RF_1 = sfs_forward_RF_1.fit(X_age, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_RF_1.k_feature_names_

sfs_forward_RF_features =  pd.DataFrame(sfs_forward_RF_1.k_feature_names_)

# try backwards

sfs_back_RF_1 = sfs_back_RF_1.fit(X_age, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_RF_1.k_feature_names_

sfs_back_RF_features =  pd.DataFrame(sfs_back_RF_1.k_feature_names_)

## irish 

DF_Irish = DF[['Irish_Daily_Outside_Educ_pct','Irish_Daily_And_In_Educ_pct']]

feature_names = DF_Irish.columns

DF_Irish.columns = feature_names

X_Irish = pd.DataFrame(min_max_scaler.fit_transform(DF_Irish))

# try forwards

sfs_forward_1= sfs_forward_1.fit(X_Irish, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_forward_1.k_feature_names_


# try backwards

sfs_back_1= sfs_back_1.fit(X_Irish, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_back_1.k_feature_names_

# try forwards
sfs_forward_SVM_1 = sfs_forward_SVM_1.fit(X_Irish, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_SVM_1.k_feature_names_

sfs_forward_SVM_features =  pd.DataFrame(sfs_forward_SVM_1.k_feature_names_)


# try backwards

sfs_back_SVM_1 = sfs_back_SVM_1.fit(X_Irish, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_SVM_1.k_feature_names_

sfs_back_SVM_features =  pd.DataFrame(sfs_back_SVM_1.k_feature_names_)

# try forwards
sfs_forward_RF_1 = sfs_forward_RF_1.fit(X_Irish, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_RF_1.k_feature_names_

sfs_forward_RF_features =  pd.DataFrame(sfs_forward_RF_1.k_feature_names_)

# try backwards

sfs_back_RF_1 = sfs_back_RF_1.fit(X_Irish, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_RF_1.k_feature_names_

sfs_back_RF_features =  pd.DataFrame(sfs_back_RF_1.k_feature_names_)


## education

DF_Edu = DF[['Degree_or_higher_pct','Ord_Degree_or_higher_pct', 'socio_A_B_pct']]

feature_names = DF_Edu.columns

DF_Edu.columns = feature_names

X_Edu = pd.DataFrame(min_max_scaler.fit_transform(DF_Edu))

# try forwards

sfs_forward_1= sfs_forward_1.fit(X_Edu, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_forward_1.k_feature_names_


# try backwards

sfs_back_1= sfs_back_1.fit(X_Edu, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_back_1.k_feature_names_

# try forwards
sfs_forward_SVM_1 = sfs_forward_SVM_1.fit(X_Edu, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_SVM_1.k_feature_names_

sfs_forward_SVM_features =  pd.DataFrame(sfs_forward_SVM_1.k_feature_names_)


# try backwards

sfs_back_SVM_1 = sfs_back_SVM_1.fit(X_Edu, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_SVM_1.k_feature_names_

sfs_back_SVM_features =  pd.DataFrame(sfs_back_SVM_1.k_feature_names_)

# try forwards
sfs_forward_RF_1 = sfs_forward_RF_1.fit(X_Edu, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_RF_1.k_feature_names_

sfs_forward_RF_features =  pd.DataFrame(sfs_forward_RF_1.k_feature_names_)

# try backwards

sfs_back_RF_1 = sfs_back_RF_1.fit(X_Edu, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_RF_1.k_feature_names_

sfs_back_RF_features =  pd.DataFrame(sfs_back_RF_1.k_feature_names_)


# load reduced dataset for further feature selection on entire feature space

feature_names = DF.columns

X = DF

X.columns = feature_names

min_max_scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))

X= pd.DataFrame(min_max_scaler.fit_transform(X))

# take off removed features

DF.pop('Ireland_birth_pct').values
DF.pop('Irish_Daily_Outside_Educ_pct').values
DF.pop('Two_person_household_hou_pct').values
DF.pop('Apartment_household_hou_pct').values
DF.pop('Apartment_household_pp_pct').values
DF.pop('Rental_private_hou_pct').values
DF.pop('Rental_private_household_pp_pct').values
DF.pop('Ord_Degree_or_higher_pct').values
DF.pop('Over_35_pct').values
DF.pop('Wh_irish').values
DF.pop('socio_A_B_pct').values


#DTR

sfs_forward = SFS(DTR(), 
                  k_features=10, 
                  forward=True, 
                  floating=False,
                  scoring='neg_mean_squared_error',    #accuracy for classification!
                  cv=10, n_jobs = -1)

sfs_forward = sfs_forward.fit(X, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_features = sfs_forward.k_feature_names_

sfs_forward_DTR_features = pd.DataFrame(sfs_forward.k_feature_names_)

svm_mask = np.in1d(feature_names, sfs_forward_features)




# SVM R

sfs_forward_SVM = SFS(SVR(), 
                  k_features=10, 
                  forward=True, 
                  floating=False,
                  scoring='neg_mean_squared_error',    #accuracy for classification!
                  cv=10, n_jobs = -1)

sfs_forward_SVM = sfs_forward_SVM.fit(X, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_SVM.k_feature_names_

sfs_forward_SVM_features =  pd.DataFrame(sfs_forward_SVM.k_feature_names_)

# RFR
sfs_forward = SFS(RFR(), 
                  k_features=10, 
                  forward=True, 
                  floating=False,
                  scoring='neg_mean_squared_error',    #accuracy for classification!
                  cv=10, n_jobs = -1)

sfs_forward = sfs_forward.fit(X, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_features = sfs_forward.k_feature_names_

sfs_forward_DTR_features = pd.DataFrame(sfs_forward.k_feature_names_)

svm_mask = np.in1d(feature_names, sfs_forward_features)


## polling date ranges



# repeat for culture/ethnicity


DF_polls = DF[['FP_Share_Plus_Polls_Recent','FP_Share_Plus_Polls_1Mo','FP_Share_Plus_Polls_3Mo']]

feature_names = DF_polls.columns

DF_polls.columns = feature_names

X_polls = pd.DataFrame(min_max_scaler.fit_transform(DF_polls))

# try forwards

sfs_forward_1= sfs_forward_1.fit(X_polls, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_forward_features = pd.DataFrame(sfs_forward_1.k_feature_names_)

svm_mask = np.in1d(feature_names, sfs_forward_features)

# try backwards

sfs_back_1= sfs_back_1.fit(X_polls, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time


sfs_back_features = pd.DataFrame(sfs_back_1.k_feature_names_)

# try forwards
sfs_forward_SVM_1 = sfs_forward_SVM_1.fit(X_polls, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_SVM_1.k_feature_names_

sfs_forward_SVM_features =  pd.DataFrame(sfs_forward_SVM_1.k_feature_names_)


# try backwards

sfs_back_SVM_1 = sfs_back_SVM_1.fit(X_polls, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_SVM_1.k_feature_names_

sfs_back_SVM_features =  pd.DataFrame(sfs_back_SVM_1.k_feature_names_)

# try forwards
sfs_forward_RF_1 = sfs_forward_RF_1.fit(X_polls, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_forward_RF_1.k_feature_names_

sfs_forward_RF_features =  pd.DataFrame(sfs_forward_RF_1.k_feature_names_)

# try backwards

sfs_back_RF_1 = sfs_back_RF_1.fit(X_polls, y, 
                              custom_feature_names=feature_names) # Make sure feature names is set ahead of time

sfs_back_RF_1.k_feature_names_

sfs_back_RF_features =  pd.DataFrame(sfs_back_RF_1.k_feature_names_)


